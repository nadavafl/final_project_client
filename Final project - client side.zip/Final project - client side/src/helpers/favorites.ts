import { supplierAlerts } from "./supplierAlerts";
import axios from "axios";
import { IProduct } from "../types/models";

interface AddRemoveFavoriteParams {
  userRole: string;
  page: string;
  itemId: string | undefined;
  token: string;
  selectedProduct?: IProduct | null;
}

export const addRemoveFavorite = (params: AddRemoveFavoriteParams): any => {
  if (params.userRole === "guest") {
    supplierAlerts.isGuestFav(params.selectedProduct);
  } else if (params.page === "supplier") {
    return axios({
      method: "patch",
      url: `http://localhost:8080/api/v1/users/favoriteSupplier/${params.itemId}`,
      headers: {
        Authorization: `Bearer ${params.token}`,
      },
    });
  } else if (params.page === "product") {
    return axios({
      method: "patch",
      url: `http://localhost:8080/api/v1/users/favoriteProduct/${params.itemId}`,
      headers: {
        Authorization: `Bearer ${params.token}`,
      },
    });
  }
};
