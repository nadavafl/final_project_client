import { userServices } from "../services/user.service";
import { decodeToken } from "../utils/jwtDecode";

export const isFavorite = async (
  itemId: string,
  type: "Supplier" | "Product"
): Promise<boolean> => {
  const id = decodeToken()?.id ?? "";
  try {
    if (!id) return false;
    const data = await userServices.getUser(id);
    if (type === "Supplier") {
      return (
        data?.favoriteSupplier.some((item: any) => item._id === itemId) ?? false
      );
    } else if (type === "Product") {
      return (
        data?.favoriteProduct.some((item: any) => item._id === itemId) ?? false
      );
    }
    return false;
  } catch (error) {
    console.error(error);
    return false;
  }
};
