import { showAlert } from "../utils/alert";
import { IProduct } from "../types/models";

const isGuestFav = (selectedProduct?: IProduct | null) => {
  if (!selectedProduct) {
    showAlert("info", "You need to be logged in to add to favourites", "info");
  } else {
    showAlert(
      "info",
      "You need to be logged in to add to favourites",
      "info",
      "OK",
      "center-right"
    );
  }
};

const response = (
  responseData: string,
  selectedProduct?: IProduct | null,
  navigate?: any
) => {
  const response = {
    supplierAdd: "Supplier added to favorites",
    supplierRemove: "Supplier removed from favorites",
    productAdd: "Product added to favorites",
    productRemove: "Product removed from favorites",
    cartUpdate: "Cart updated",
  };
  if (
    responseData === response.supplierAdd ||
    responseData === response.supplierRemove
  ) {
    showAlert("Success", responseData, "success");
  } else if (
    (responseData === response.productAdd && selectedProduct) ||
    (responseData === response.productRemove && selectedProduct)
  ) {
    showAlert("Success", responseData, "success", "OK", "center-right");
  } else if (
    responseData === response.productAdd ||
    responseData === response.productRemove
  ) {
    showAlert("Success", responseData, "success");
  } else if (responseData === response.cartUpdate && selectedProduct) {
    showAlert(
      "Cart updated",
      responseData,
      "success",
      "OK",
      "center-right",
      false,
      navigate,
      `<button id="goToCartButton" class="swal2-confirm swal2-styled">Go to my cart</button>
   <button id="continueShoppingButton" class="swal2-confirm swal2-styled">Continue</button>`
    );
  } else if (responseData === response.cartUpdate) {
    showAlert(
      "Cart updated",
      responseData,
      "success",
      "OK",
      "center",
      false,
      navigate,
      `<button id="goToCartButton" class="swal2-confirm swal2-styled">Go to my cart</button>
   <button id="continueShoppingButton" class="swal2-confirm swal2-styled">Continue</button>`
    );
  } else {
    showAlert("error", responseData, "error");
  }
};

const isGuestCart = (selectedProduct?: IProduct | null) => {
  if (!selectedProduct) {
    showAlert("info", "You need to be logged in to add to cart", "info");
  } else {
    showAlert(
      "info",
      "You need to be logged in to add to cart",
      "info",
      "OK",
      "center-right"
    );
  }
};

export const supplierAlerts = { isGuestFav, response, isGuestCart };
