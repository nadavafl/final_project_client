export const handleMouseEnter =
  (darkMode: boolean) => (e: any) => {
    if (darkMode) {
      e.currentTarget.style.backgroundColor = "#4B5563";
    }
  };

export const handleMouseLeave =
  (darkMode: boolean) => (e: any) => {
    if (darkMode) {
      e.currentTarget.style.backgroundColor = "#1f2937";
    }
  };
