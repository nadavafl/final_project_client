import { showAlert } from "../utils/alert";

const deleteCart = () => {
  showAlert("Deleted", "Cart deleted", "success");
};

const removeItem = () => {
  showAlert("Removed", "Item removed from cart", "success");
};

const payment = () => {
  showAlert("Payment", "Payment successful, thank you!", "success");
};

export const cartAlerts = { deleteCart, removeItem, payment };
