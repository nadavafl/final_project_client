import { useMutation } from "react-query";
import { useForm } from "react-hook-form";
import { decodeToken } from "../utils/jwtDecode";
import { useUser } from "../hooks/useUser";
import { Link, useNavigate } from "react-router-dom";
import { ILogin } from "../types/models";
import { yupUserLoginSchema } from "../validators/userLogin.yup.yup";
import { yupResolver } from "@hookform/resolvers/yup";
import FormLogin from "../components/form/FormLogin";
import { showAlert } from "../utils/alert";
import axios from "axios";

const Login = () => {
  const { setUser } = useUser();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<ILogin>({
    resolver: yupResolver<ILogin>(yupUserLoginSchema),
    mode: "onBlur",
  });

  const mutation = useMutation(
    (data: ILogin) =>
      axios.post("http://localhost:8080/api/v1/users/login", data),
    {
      onSuccess: (data) => {
        const token = JSON.stringify(data.data.token);
        sessionStorage.setItem("token", token);
        setUser(decodeToken()?.role || "guest");
        reset();
        navigate(`/${decodeToken()?.id}`);
        showAlert("Success", "Logged in successfully", "success");
      },
      onError: (error: any) => {
        showAlert("Error", error.response.data.message, "error");
        showAlert("Error", error.response.data.details[0].message, "error");
      },
    }
  );

  const onSubmit = (data: ILogin) => {
    mutation.mutate(data);
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col items-center justify-center gap-5 w-full"
      >
        <h1 className="text-5xl font-bold">Login</h1>
        <div className="flex flex-col items-center text-3xl font-bold w-full p-3 mb-10">
          <FormLogin register={register} errors={errors} />
        </div>
        <button
          type="submit"
          className="bg-blue-700 text-white mb-10 p-3 w-1/2 rounded-md text-4xl font-semibold"
        >
          Login
        </button>
        <p className="text-xl">Not registered?</p>
        <Link
          className="bg-blue-400 text-white p-3 w-1/2 rounded-md text-center text-2xl"
          to="/register"
        >
          Register
        </Link>
      </form>
    </div>
  );
};

export default Login;
