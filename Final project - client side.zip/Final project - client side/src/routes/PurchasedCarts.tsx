import { useQuery } from "react-query";
import { decodeToken } from "../utils/jwtDecode";
import { cartService } from "../services/cart.service";
import { useHideCart } from "../hooks/useHideCart";
import { ICart } from "../types/models";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import CartCard from "../components/cart/CartInfo";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const PurchasedCarts = () => {
  const { darkMode } = useContext(ThemeContext);
  const id = decodeToken()?.id;
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  const { isLoading, isError, data, refetch } = useQuery("myCarts", () =>
    cartService.getUserCart(id, token)
  );
  const deleteMutation = useHideCart(token, refetch);
  const paidCarts =
    data?.paidCarts && data.paidCarts.filter((cart: ICart) => !cart.hideCart);

  const deleteCart = (userId: string, invoiceId: string) => {
    deleteMutation.mutate({ userId, invoiceId });
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (paidCarts) {
    return (
      <div className="flex flex-col text-center text-2xl tracking-widest font-bold min-h-screen">
        <h1>My purchased carts</h1>
        <div className="flex flex-wrap justify-center m-10">
          {!paidCarts.length ? (
            <h2 className="mt-40">No carts found</h2>
          ) : (
            paidCarts.map((cart) => (
              <CartCard
                key={cart.invoice._id}
                cart={cart}
                onDelete={() => deleteCart(id ?? "", cart.invoice._id)}
                darkMode={darkMode}
              />
            ))
          )}
        </div>
      </div>
    );
  }
};

export default PurchasedCarts;
