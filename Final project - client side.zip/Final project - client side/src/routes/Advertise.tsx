import { faDownLong } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";

const Advertise = () => {
  return (
    <div className="flex flex-col h-screen text-center p-20 space-y-10 text-3xl">
      <h1 className="text-6xl font-bold mb-4">Advertise</h1>
      <p>Welcome to Metro!</p>
      <p>
        Are you looking for an effective platform to showcase your brand or
        product? Look no further!
      </p>
      <p>
        {" "}
        Our homepage is the perfect space to reach a diverse audience of engaged
        visitors. With Metro, you have the opportunity to advertise your
        business prominently on our homepage, gaining visibility and exposure to
        potential customers.
      </p>
      <p>
        {" "}
        Whether you're promoting a new product, service, event, or simply
        seeking to increase brand awareness, advertising with us offers a
        strategic advantage.
      </p>
      <p>
        {" "}
        Get in touch with us today to discuss advertising opportunities and
        tailor a plan that suits your specific needs.
      </p>
      <p>
        We're dedicated to helping your business thrive in the digital
        landscape. Contact us now to secure your placement and unlock the
        potential of advertising on Metro!
      </p>
      <div className="text-8xl">
         <FontAwesomeIcon icon={faDownLong} />
      </div>
     
      <Link
        className="text-5xl font-bold hover:text-blue-300"
        to="/contact"
      >
        Contact
      </Link>
    </div>
  );
};

export default Advertise;
