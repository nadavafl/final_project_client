const AboutUs = () => {
  return (
    <div className="prose lg:prose-xl mx-auto p-4 text-justify px-96 pt-10 text-3xl">
      <h2 className="font-bold text-6xl mb-4 text-center">About Metroline</h2>
      <p>
        Metroline is a unique marketplace dedicated to empowering suppliers
        around the globe. We provide a robust platform for suppliers to showcase
        their products, reach a wider audience, and conduct business seamlessly.
        Our mission is to bridge the gap between suppliers and businesses, as
        well as private customers who meet the minimum requirements. We believe
        in creating opportunities for all, fostering growth, and promoting a
        vibrant business ecosystem. With Metroline, suppliers can not only
        present their products but also sell and ship them directly to other
        businesses and private customers. We have integrated a streamlined
        process that ensures a smooth transaction, from showcasing products to
        delivering them to the customer's doorstep.
      </p>
      <h3 className="font-bold text-4xl mb-4 mt-6 text-center">
        Easy to Register
      </h3>
      <p>
        At Metroline, we believe in making things easy for our users. That's why
        we've made our registration process as simple as possible. With just a
        few clicks, you can set up your account and start selling or buying
        products.
      </p>
      <h3 className="font-bold text-4xl mb-4 mt-6 text-center">
        User-Friendly Platform
      </h3>
      <p>
        Metroline is designed with users in mind. Our platform is easy to
        navigate, making it simple for suppliers to list their products and for
        customers to find what they're looking for. Plus, our dedicated support
        team is always ready to help if you have any questions or issues. We
        invite you to join Metroline, whether you're a supplier looking to
        expand your reach, a business seeking quality products, or a private
        customer in search of unique items. Together, we can create a thriving
        marketplace that benefits everyone.
      </p>
    </div>
  );
};

export default AboutUs;
