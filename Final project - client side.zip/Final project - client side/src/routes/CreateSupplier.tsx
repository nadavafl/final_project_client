import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useNavigate } from "react-router-dom";
import { ISupplier, ISupplierInput } from "../types/models";
import { showAlert } from "../utils/alert";
import FormAddress from "../components/form/FormAddress";
import { useMutation } from "react-query";
import FormSupplier from "../components/supplier/FormSupplier";
import FormSupplierOnline from "../components/supplier/FormSupplierOnline";
import { yupSupplierSchema } from "../validators/supplierRegistrion.yup";
import { supplierServices } from "../services/supplier.service";
import { supplierValues } from "../constants/supplier.constants";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const CreateSupplier = () => {
  const { darkMode } = useContext(ThemeContext);
  const navigate = useNavigate();
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<ISupplierInput>({
    resolver: yupResolver<ISupplierInput | any>(yupSupplierSchema),
    mode: "onBlur",
  });
  const mutation = useMutation(
    (data: ISupplier) => supplierServices.registerSupplier(data),
    {
      onSuccess: (data: any) => {
        if (data.massege === "supplier created") {
          reset();
          showAlert("Success", "Registered successfully", "success");
          navigate("/myBusinesses");
        }
      },
      onError: (error: any) => {
        showAlert("Error", error.response.data.message, "error");
        showAlert("Error", error.response.data.details[0].message, "error");
      },
    }
  );
  const onSubmit = (data: ISupplier) => {
    mutation.mutate(data);
  };

  const [bizTypeInput, setBizTypeInput] = useState([] as string[]);

  const [chooseBizType, setChooseBizType] = useState(false);
  useEffect(() => {
    setValue("businessType", { type: [] } as any);
  }, [setValue]);

  const handleCheckboxChange = (type: string, checked: boolean) => {
    let businessType: any = getValues("businessType") || { type: [] };

    if (checked) {
      if (Array.isArray(businessType.type)) {
        businessType.type.push(type);
      } else {
        console.error("businessType.type is not an array");
      }
    }
    setValue("businessType", businessType);
  };

  return (
    <div
      className="flex flex-col p-10 items-center justify-center text-3xl font-bold w-full 
   h-full"
    >
      <h1 className="pt-5">Create new supplier</h1>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex pt-8 text-3xl font-bold from-neutral-950 w-full"
      >
        <div className="flex flex-col justify-start items-center h-full text-3xl font-bold w-full">
          <div className="flex justify-start h-1/2 text-3xl font-bold w-full">
            <div className="flex flex-col items-end h-full text-3xl font-bold w-1/2 mx-3">
              <div className={chooseBizType ? "overlay" : ""} />
              <FormSupplier
                register={register}
                errors={errors}
                values={supplierValues}
                useDefaultValue={false}
                isDisabled={false}
                handleCheckboxChange={handleCheckboxChange}
                chooseBizType={chooseBizType}
                setChooseBizType={setChooseBizType}
                setValue={setValue}
                bizTypeInput={bizTypeInput}
                setBizTypeInput={setBizTypeInput}
                darkMode={darkMode}
              />
            </div>
            <div className="flex flex-col items-start h-full text-3xl font-bold w-1/2 mx-3">
              <FormAddress
                register={register}
                errors={errors}
                values={supplierValues}
                useDefaultValue={false}
                isDisabled={false}
                darkMode={darkMode}
              />
            </div>
          </div>
          <div className="flex flex-raw items-center justify-center h-full text-3xl font-bold w-2/3 ">
            <FormSupplierOnline
              register={register}
              errors={errors}
              values={supplierValues}
              useDefaultValue={false}
              isDisabled={false}
              darkMode={darkMode}
            />
          </div>
          <div className=" items-center justify-center w-full h-full text-center mt-12">
            <button
              type="submit"
              className="bg-blue-500 hover:bg-blue-400 text-white p-3 w-1/2 rounded-md"
            >
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default CreateSupplier;
