import { useParams } from "react-router-dom";
import { useMutation, useQuery } from "react-query";
import { webServices } from "../services/web.service";
import { useUser } from "../hooks/useUser";
import { useState, useEffect } from "react";
import SupplierInfo from "../components/content/SupplierInfo";
import ProductShortCard from "../components/content/ProductShortCard";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import { supplierAlerts } from "../helpers/supplierAlerts";
import { productService } from "../services/product.service";
import { ICart, IProduct } from "../types/models";
import ProductFullCard from "../components/content/ProductFullCard";
import { addRemoveFavorite } from "../helpers/favorites";
import { cartService } from "../services/cart.service";
import { isFavorite } from "../helpers/isFavorite";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import { set, get } from "idb-keyval";

const Supplier = () => {
  const { darkMode } = useContext(ThemeContext);
  const { id } = useParams();
  const { supplierId } = useParams();
  let token = sessionStorage.getItem("token");
  const userToken = token ? JSON.parse(token) : "guest";
  const userRole = useUser().user;

  const [responseData, setResponseData] = useState() as any; 

  const [selectedProduct, setSelectedProduct] = useState<IProduct | null>(null);

  useEffect(() => {
    get("selectedProduct").then((value: IProduct | null) =>
      setSelectedProduct(value)
    );
  }, []);

  useEffect(() => {
    set("selectedProduct", selectedProduct);
  }, [selectedProduct]);

  useEffect(() => {
    if (typeof responseData !== "string" && responseData) {
      supplierAlerts.response(responseData.message, selectedProduct);
    }
  }, [responseData]);

  const fetchProduct = async (productId: string) => {
    const data = (await productService.getProductById(productId)) as any; 
    setSelectedProduct(data[0]);
    refetch();
  };

  const { data, error, isLoading, refetch } = useQuery(
    "get-suppliers",
    async () => {
      const [suppliers, products, carts] = await Promise.all([
        webServices.getSuppliers(),
        webServices.getSupplierProducts(supplierId ?? ""),
        cartService.getUserCart(id ?? "", userToken),
      ]);

      if (carts) {
        carts.unpaidCarts = carts.unpaidCarts.filter(
          (cart: ICart) => !cart.isPaid
        );
      }
      return { suppliers, products, carts };
    }
  );

  const mutation = useMutation(addRemoveFavorite, {
    onSuccess: (data: { data: string }) => {
      refetch();
      setResponseData(data?.data);
    },
  });

  const supplier = data?.suppliers?.find(
    (supplier) => supplier._id === supplierId
  );
  const products = data?.products;

  const carts = data?.carts ? (data?.carts.unpaidCarts as ICart[]) : [];

  const onAddToFavourites = (
    itemId: string,
    page: string,
    selectedProduct?: IProduct
  ) => {
    mutation.mutate({
      userRole: userRole,
      page: page,
      itemId: itemId,
      token: userToken,
      selectedProduct: selectedProduct,
    });
  };

  if (isLoading) return <Loading />; 
  if (error) return <Error />; 

  return (
    supplier && (
      <div className={"flex flex-col w-full"}>
        <SupplierInfo
          supplier={supplier}
          onAddToFavourites={onAddToFavourites}
          userRole={userRole}
          refetch={refetch}
          isFavorite={isFavorite}
        />
        <div className="flex flex-wrap items-center justify-center m-5">
          {products?.map((product, index) => (
            <ProductShortCard
              key={product._id || index}
              userId={id ?? ""}
              supplierId={supplierId ?? ""}
              userToken={userToken}
              product={product}
              refetch={refetch}
              carts={carts}
              getProductById={() => {
                fetchProduct(product._id);
              }}
              onAddToFavourites={onAddToFavourites}
              userRole={userRole}
              isFavorite={isFavorite}
              darkMode={darkMode}
            />
          ))}
        </div>
        {selectedProduct && (
          <div>
            <div className={selectedProduct ? "overlay" : ""} />
            <div className="flex flex-wrap items-center justify-center m-5">
              <ProductFullCard 
                className={selectedProduct ? "fullInfoProduct" : ""}
                userId={id ?? ""}
                supplierId={supplierId ?? ""}
                userToken={userToken}
                product={selectedProduct}
                refetch={refetch}
                carts={carts}
                setSelectedProduct={setSelectedProduct}
                onAddToFavourites={onAddToFavourites}
                isFavorite={isFavorite}
                darkMode={darkMode}
              />
            </div>
          </div>
        )}
      </div>
    )
  );
};

export default Supplier;
