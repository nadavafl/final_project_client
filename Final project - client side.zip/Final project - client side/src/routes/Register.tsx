import { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { Link, useNavigate } from "react-router-dom";
import { IUserInput } from "../types/models";
import { showAlert } from "../utils/alert";
import { yupUserSchema } from "../validators/userRegistrion.yup";
import FormAddress from "../components/form/FormAddress";
import FormUser from "../components/user/FormUser";
import FormRole from "../components/user/Role";
import { useMutation } from "react-query";
import Password from "../components/user/Password";
import { userServices } from "../services/user.service";
import { UserValues } from "../constants/user.constants";

const Register = () => {
  const [isContinue, setContinue] = useState(false);
  const navigate = useNavigate();

  const {
    register,
    setValue,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm<IUserInput>({
    resolver: yupResolver<IUserInput>(yupUserSchema),
    mode: "onBlur",
  });

  const mutation = useMutation(
    (data: IUserInput) => userServices.registerUser(data),
    {
      onSuccess: (data: any) => {
        if (data.message === "User created") {
          reset();
          showAlert("Success", "Registered successfully", "success");
          navigate("/login");
        }
      },
      onError: (error: any) => {
        showAlert("Error", error.response.data.message, "error");
        showAlert("Error", error.response.data.details[0].message, "error");
      },
    }
  );
  const onSubmit = (data: IUserInput) => {
    if (data.password !== data.repeatPassword) {
      showAlert("Error", "Passwords do not match", "error");
    }
    const newUser: IUserInput = {
      name: {
        first: data.name.first,
        middle: data.name.middle,
        last: data.name.last,
      },
      phone: data.phone,
      email: data.email,
      address: {
        country: data.address.country,
        state: data.address.state,
        city: data.address.city,
        street: data.address.street,
        houseNumber: data.address.houseNumber,
        postalCode: data.address.postalCode,
      },
      password: data.password,
      role: {
        name: data.role?.name as string,
      },
    };
    mutation.mutate(newUser);
  };

  return (
    <div
      className="flex flex-col p-10 items-center justify-center text-3xl font-bold w-full 
   h-full"
    >
      <h1 className="pt-5">Register</h1>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex pt-8 text-3xl font-bold from-neutral-950 w-full"
      >
        <div className="flex flex-col justify-start text-3xl font-bold w-full p-16">
          <div className="flex justify-start text-3xl font-bold w-full">
            <div className="flex flex-col items-end h-full text-3xl font-bold w-1/2 p-3">
              <FormUser
                register={register}
                errors={errors}
                values={UserValues}
                useDefaultValue={false}
                isDisabled={false}
              />
            </div>
            <div className="flex flex-col items-start h-full text-3xl font-bold w-1/2 p-3">
              <FormAddress
                register={register}
                errors={errors}
                values={UserValues}
                useDefaultValue={false}
                isDisabled={false}
              />
            </div>
          </div>
          <div className="flex flex-col items-center w-full">
            <Password register={register} errors={errors} values={UserValues} />
          </div>
          {isContinue && (
            <FormRole errors={errors} setValue={setValue} watch={watch} />
          )}
          <div className="flex flex-col items-center w-full mt-12">
            {!isContinue && (
              <button
                type="button"
                className="bg-blue-700 text-white mb-10 p-3 w-1/2 rounded-md font-semibold"
                onClick={() => {
                  setContinue(!isContinue);
                }}
              >
                {isContinue ? null : "Choose subscription"}
              </button>
            )}
          </div>
          <div className="flex flex-col items-center w-full">
            {isContinue && (
              <button
                type="submit"
                className="bg-blue-500 text-white p-3 w-1/2 rounded-md"
              >
                Register
              </button>
            )}
          </div>
        </div>
      </form>
      <p className="pt-5">Already have an account?</p>
      <Link
        className="bg-blue-400 text-white mt-5 p-3 w-1/2 rounded-md text-center"
        to="/login"
      >
        Login
      </Link>
    </div>
  );
};

export default Register;
