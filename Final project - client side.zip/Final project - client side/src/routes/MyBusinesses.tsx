import { useQuery } from "react-query";
import { supplierServices } from "../services/supplier.service";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import DbImage from "../components/web/ImageHandler";
import { Link } from "react-router-dom";
import { ISupplier } from "../types/models";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const MyBusinesses = () => {
  const { data, isLoading, isError } = useQuery(["myBusinesses"], () =>
    supplierServices.myBusinesses()
  );
  const { darkMode } = useContext(ThemeContext);
  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    const dataArray = Array.isArray(data) ? data : [data];
    return (
      <div className="flex flex-col items-center min-h-screen">
        <h1>My Businesses</h1>
        <div className="flex flex-wrap items-center justify-center mt-20 w-full min-h-full sm:w-1/2 md:w-1/2 lg:w-3/4">
          {dataArray?.map((supplier: ISupplier) => (
            <Link
              key={supplier._id}
              className="flex justify-center h-1/3 w-1/4"
              to={`/businessPage/${supplier._id}`}
            >
              <div
                style={{ backgroundColor: darkMode && "#1f2937" }}
                className="block items-center justify-center m-3 p-2 min-h-full w-full cursor-pointer"
                id="card"
              >
                <h1 className="text-center font-bold text-4xl">
                  {supplier.title}
                </h1>
                {supplier.image?.file?.data ? (
                  <div className="object-cover">
                    <DbImage
                      image={supplier.image}
                      title={supplier.title}
                      showBtn={false}
                      style={{
                        maxHeight: "35rem",
                        minHeight: "16.5rem",
                        width: "650px",
                        height: "350px",
                      }}
                    />
                  </div>
                ) : (
                  <div>{supplier.subtitle}</div>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    );
  }
};

export default MyBusinesses;
