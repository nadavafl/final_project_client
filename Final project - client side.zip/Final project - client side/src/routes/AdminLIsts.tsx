import { useQuery } from "react-query";
import { useParams } from "react-router-dom";
import { adminServices } from "../services/admin.service";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import UserList from "../components/admin/UsersList";
import SuppliersList from "../components/admin/SuppliersList";
import CartsList from "../components/admin/CartsList";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const AdminLists = () => {
  const { darkMode } = useContext(ThemeContext);
  const { list } = useParams();
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  const { data, isError, isLoading, refetch } = useQuery(
    ["adminLists", list],
    async () => {
      const [users, suppliers, carts] = await Promise.all([
        adminServices.getUsers(token || ""), 
        adminServices.getSuppliers(),
        adminServices.getCarts(token || "")
      ]);
      return { users, suppliers, carts };
    }
  );

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div className="flex flex-col min-h-screen w-full">
        {list === "users" && (
          <UserList users={data.users} refetch={refetch} darkMode={darkMode} />
        )}
        {list === "suppliers" && (
          <SuppliersList
            suppliers={data.suppliers}
            refetch={refetch}
            darkMode={darkMode}
          />
        )}
        {list === "carts" && (
          <CartsList carts={data.carts} refetch={refetch} darkMode={darkMode} />
        )}
      </div>
    );
  }
};

export default AdminLists;
