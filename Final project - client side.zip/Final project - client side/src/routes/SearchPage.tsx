import { useQuery } from "react-query";
import { Link, useParams } from "react-router-dom";
import { searchService } from "../services/search.service";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import { useEffect } from "react";
import { useUser } from "../hooks/useUser";
import { decodeToken } from "../utils/jwtDecode";

const SearchPage = () => {
  const { user } = useUser();
  let { id } = useParams();
  if (user.toString() === "guest") {
    id = "guest";
  } else {
    const decodedToken = decodeToken();
    id = decodedToken?.id || "";
  }
  const { searchInput } = useParams() as { searchInput: string };
  const { data, isLoading, isError, refetch } = useQuery(
    ["search", searchInput],
    () => {
      return searchService.GeneralSearch(searchInput);
    },
    { enabled: !!searchInput }
  );

  useEffect(() => {
    refetch();
  }, [searchInput, refetch]);

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div className="flex flex-col flex-wrap p-16 w-9/12 ml-24">
        <h1 className="flex justify-center my-16">
          Search Results for "{searchInput}"
        </h1>
        <h1>Categories</h1>
        {data.categories.length ? (
          data.categories.map((category) => (
            <Link
              className="flex ml-5 text-3xl text-blue-700 hover:underline my-2"
              to={`/byCategory/${category}`}
              key={category}
            >
              {category}
            </Link>
          ))
        ) : (
          <p className="text-2xl">No categories found for this search</p>
        )}
        <h1>Suppliers</h1>
        {data.suppliersInfo.length ? (
          data.suppliersInfo.map((supplier) => (
            <div key={supplier._id} className="flex flex-col p-3">
              <Link
                className="text-3xl text-blue-700 hover:underline"
                to={`/supplier/${id}/${supplier._id}`}
              >
                {supplier.title}
              </Link>
              <div className="text-2xl">
                <p>{supplier.subtitle}</p>
                <p>{supplier.description}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-2xl">No suppliers found for this search</p>
        )}
        <h1>Products</h1>
        {data.productsInfo.length ? (
          data.productsInfo.map((product) => (
            <div key={product._id} className="p-5">
              <Link
                className="text-3xl text-blue-700 hover:underline"
                to={`/supplier/${id}/${product.supplier_id}`}
              >
                {product.title}
              </Link>
              <div className="flex space-x-4 text-2xl">
                <p>{product.description}</p>
                <p>price: {product.price}</p>
                <p>{product.inStock ? "In stock" : "Out of stock"}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-2xl">No products found for this search</p>
        )}
      </div>
    );
  }
};

export default SearchPage;
