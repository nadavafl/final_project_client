import { Route, Routes } from "react-router-dom";
import HomePage from "./HomePage";
import AdminLists from "./AdminLIsts";
import AboutUs from "./AboutUs";
import Favorites from "./Favorites";
import Advertise from "./Advertise";
import Contact from "./Contact";
import CreateSupplier from "./CreateSupplier";
import MyBusinesses from "./MyBusinesses";
import Supplier from "./Supplier";
import ByCategory from "./ByCategory";
import Register from "./Register";
import Login from "./Login";
import JoinUs from "./JoinUs";
import MyCarts from "./MyCarts";
import PurchasedCarts from "./PurchasedCarts";
import UpdateUser from "./UpdateUser";
import BusinessPage from "./BusinessPage";
import SearchPage from "./SearchPage";
import NotFound from "./NotFound";

export const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<HomePage />} />
    <Route path="/:id" element={<HomePage />} />
    <Route path="/adminLists/:list" element={<AdminLists />} />
    <Route path="/aboutUs" element={<AboutUs />} />
    <Route path="/favorites" element={<Favorites />} />
    <Route path="/advertise" element={<Advertise />} />
    <Route path="/contact" element={<Contact />} />
    <Route path="/createSupplier" element={<CreateSupplier />} />
    <Route path="/myBusinesses" element={<MyBusinesses />} />
    <Route path="/supplier/:id/:supplierId" element={<Supplier />} />
    <Route path="/byCategory/:category" element={<ByCategory />} />
    <Route path="/register" element={<Register />} />
    <Route path="/login" element={<Login />} />
    <Route path="/joinUs" element={<JoinUs />} />
    <Route path="/myCarts" element={<MyCarts />} />
    <Route path="/purchasedCarts" element={<PurchasedCarts />} />
    <Route path="/update/:id" element={<UpdateUser />} />
    <Route path="/businessPage/:id" element={<BusinessPage />} />
    <Route path="/search/:searchInput" element={<SearchPage />} />
    <Route path="*" element={<NotFound />} />
  </Routes>
);
