import { useQuery } from "react-query";
import { webServices } from "../services/web.service";
import { useParams } from "react-router-dom";
import { memo } from "react";
import { useUser } from "../hooks/useUser";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import MainCategory from "../components/homePage/MainCategories";
import MainSupplier from "../components/homePage/MainSuppliers";
import MainProduct from "../components/homePage/MainProducts";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import ImagesCarousel from "../components/web/Images carousel";
import adv1 from "../assets/adv1.webp";
import adv2 from "../assets/adv2.jpg";

const HomePage = () => {
  const { darkMode } = useContext(ThemeContext);
  const { data, isError, isLoading } = useQuery("get-home-data", async () => {
    const [suppliers, categories, products] = await Promise.all([
      webServices.getSuppliers(),
      webServices.getcategories(),
      webServices.getProduct(),
    ]);
    return { suppliers, categories, products };
  });
  const { user } = useUser();
  let { id } = useParams();
  if (user.toString() === "guest") {
    id = "guest";
  }

  if (isLoading) return <Loading />; 
  if (isError) return <Error />; 

  if (data) {
    return (
      <div className="text-center content-center text-5xl tracking-widest font-extrabold">
        <h1 className="mt-10">METROLINE</h1>
        <h2 className="mt-10">Welcome to a world of suppliers</h2>
        <div className="flex flex-wrap items-center justify-center m-10">
          {data.categories?.map((category) => (
            <MainCategory
              category={category}
              darkMode={darkMode}
              key={`${category}`}
            />
          ))}
        </div>
        <div className="flex items-center justify-center px-32 mr-10 w-full mb-10">
          <ImagesCarousel />
        </div>
        <h1>Top Suppliers</h1>
        <div className="flex flex-wrap items-start justify-center m-10">
          {data.suppliers?.slice(0, 9).map((supplier) => (
            <MainSupplier
              supplier={supplier}
              darkMode={darkMode}
              id={id}
              key={supplier._id}
            />
          ))}
        </div>
        <div className="flex items-center justify-center px-32 mr-10 w-full mb-10">
          <img
            style={{
              maxHeight: "35rem",
              minHeight: "16.5rem",
              width: "1550px",
              height: "900px",
            }}
            className="rounded-lg"
            src={adv1}
            alt="First slide"
          />
        </div>
        <h1>Top Products</h1>
        <div className="flex flex-wrap items-center justify-center m-10">
          {data.products?.slice(0, 12).map((product) => (
            <MainProduct
              product={product}
              id={id}
              darkMode={darkMode}
              key={product._id}
            />
          ))}
        </div>
        <div className="flex items-center justify-center px-32 mr-10 w-full mb-10">
          <img
            style={{
              maxHeight: "35rem",
              minHeight: "16.5rem",
              width: "1550px",
              height: "900px",
            }}
            className="rounded-lg"
            src={adv2}
            alt="First slide"
          />
        </div>
      </div>
    );
  }
};

export default memo(HomePage);
