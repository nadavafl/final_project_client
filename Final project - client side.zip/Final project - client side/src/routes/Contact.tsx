import { useState } from "react";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import { showAlert } from "../utils/alert";

const Contact = () => {
  const { darkMode } = useContext(ThemeContext);
  const [iframeLoadError, setIframeLoadError] = useState(false);

  const handleIframeError = () => {
    setIframeLoadError(true);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    showAlert("success", "Thank you!", "success");
    e.currentTarget.reset();
  };

  return (
    <div className="flex flex-col items-center my-8 text-3xl space-y-7">
      <h1 className="text-5xl font-bold my-4">Contact Us</h1>
      <p>
        <strong>Address:</strong> Rothschild Blvd 1, Tel Aviv, Israel
      </p>
      <p>
        <strong>Phone:</strong> +972 3 1234567
      </p>
      <p>
        <strong>Email:</strong> info@email.com
      </p>

      <h2 className="text-xl font-bold mt-4 mb-2">Send us a message</h2>
      <form className="w-1/3" onSubmit={handleSubmit}>
        <label className="block mb-2">Name</label>
        <input
          style={{ backgroundColor: darkMode && "#1f2937" }}
          type="text"
          className="border p-2 mb-4 w-full"
        />

        <label className="block mb-2">Email</label>
        <input
          style={{ backgroundColor: darkMode && "#1f2937" }}
          type="email"
          className="border p-2 mb-4 w-full"
        />

        <label className="block mb-2">Message</label>
        <textarea
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="border p-2 mb-4 w-full"
          rows={4}
        ></textarea>

        <button type="submit" className="bg-blue-500 text-white p-2 rounded">
          Send
        </button>
      </form>

      <h2 className="text-xl font-bold mt-4 mb-2">Find us on the map</h2>
      <div>
        {iframeLoadError ? (
          <p>Map could not be loaded. Please visit Google Maps to find us.</p>
        ) : (
          <iframe
            title="Our Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3381.2245491812064!2d34.766407075957794!3d32.06317482012351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151d4c9c9b406983%3A0x62b689ffc3ab617b!2sRothschild%20Blvd%201%2C%20Tel%20Aviv-Jaffa!5e0!3m2!1sen!2sil!4v1707577202052!5m2!1sen!2sil"
            width="900"
            height="450"
            style={{ border: 0 }}
            allowFullScreen={true}
            loading="lazy"
            onError={handleIframeError}
          />
        )}
      </div>
    </div>
  );
};

export default Contact;
