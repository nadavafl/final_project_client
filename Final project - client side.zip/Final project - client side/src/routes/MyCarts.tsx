import { useQuery } from "react-query";
import { decodeToken } from "../utils/jwtDecode";
import { cartService } from "../services/cart.service";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import { ICart } from "../types/models";
import { useDeleteCart } from "../hooks/useDeleteCart";
import { usePayment } from "../hooks/usePayment";
import { useIncrementItem } from "../hooks/useIncrementItem";
import Cart from "../components/cart/Cart";
import { useRemoveItem } from "../hooks/useRemoveItem";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const MyCarts = () => {
  const { darkMode } = useContext(ThemeContext);
  const id = decodeToken()?.id;
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  const { isLoading, isError, data, refetch } = useQuery("myCarts", () =>
    cartService.getUserCart(id, token)
  );

  const unpaidCarts = data?.unpaidCarts.filter((cart: ICart) => !cart.isPaid);
  const deleteCart = useDeleteCart(token, refetch);
  const removeItem = useRemoveItem(token, refetch);
  const incrementItem = useIncrementItem(token, refetch);
  const payment = usePayment(token, refetch);

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (unpaidCarts) {
    return (
      <div className="flex flex-col text-center items-center text-3xl tracking-widest font-bold min-h-screen">
        <h1>My carts</h1>
        <div className="flex flex-wrap justify-center m-10 relative">
          {!unpaidCarts.length ? (
            <h2 className="mt-40">No carts found</h2>
          ) : (
            unpaidCarts.map((cart) => (
              <div
                style={{ backgroundColor: darkMode && "#1f2937" }}
                id="card"
                key={cart._id}
              >
                <Cart
                  cart={cart}
                  onDelete={() =>
                    deleteCart.mutate({
                      cartId: cart._id,
                      userId: id ?? "",
                    })
                  }
                  onRemoveItem={(productId: string) =>
                    removeItem.mutate({
                      userId: id ?? "",
                      supplierId: cart.supplier_id,
                      productId,
                    })
                  }
                  onAddReduce={(productId: string, quantity: number) =>
                    incrementItem.mutate({
                      userId: id ?? "",
                      supplierId: cart.supplier_id,
                      productId,
                      quantity,
                    })
                  }
                  onPayment={() =>
                    payment.mutate({
                      userId: id ?? "",
                      supplierId: cart.supplier_id,
                    })
                  }
                  darkMode={darkMode}
                  disableQuantity={false}
                />
              </div>
            ))
          )}
        </div>
      </div>
    );
  }
};

export default MyCarts;
