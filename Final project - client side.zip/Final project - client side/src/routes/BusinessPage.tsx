import { useQuery } from "react-query";
import { useParams } from "react-router-dom";
import { supplierServices } from "../services/supplier.service";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import { useRef, useState } from "react";
import SupplierImage from "../components/supplier/SupplierImage";
import { FieldValues, SubmitHandler } from "react-hook-form";
import SupplierDetails from "../components/supplier/SupplierDetails";
import DeliveryInfo from "../components/supplier/DeliveryInfo";
import UpdateSupplier from "../components/supplier/UpdateSupplier";
import AddProduct from "../components/supplier/AddProduct";
import DeleteSupplier from "../components/supplier/DeleteSupplier";
import { useBusinessPageState } from "../hooks/useBusinessPageState";
import { useBusinessPageHandlers } from "../hooks/useBusinessPageHandlers";
import { elements } from "../constants/product.constants";
import Carts from "../components/cart/Carts";
import SupplierSideMenu from "../components/content/SupplierSideMenu";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const BusinessPage = () => {
  const { darkMode } = useContext(ThemeContext);
  const { id } = useParams() as { id: string };
  const { data, isLoading, isError, refetch } = useQuery(
    "businessPage",
    async () => {
      const [supplier, products] = await Promise.all([
        supplierServices.getSupplierById(id),
        supplierServices.getproducts(id),
      ]);
      return { supplier, products };
    }
  );
  const fileInput = useRef(null);
  const {
    supplierDetails,
    addProduct,
    updateInfo,
    deliveryInfo,
    uploadImage,
    deleteAccount,
    carts,
    setSupplierDetails,
    setAddProduct,
    setUpdateInfo,
    setDeliveryInfo,
    setUploadImage,
    setDeleteAccount,
    setCarts,
  } = useBusinessPageState();
  const {
    handleUpdateProduct,
    inStock,
    deleteItem,
    uploadImages,
    deleteImages,
  } = useBusinessPageHandlers(id, refetch);

  const [sideMenu, setSideMenu] = useState(false);

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data?.supplier) {
    return (
      <div className="flex flex-col min-h-screen w-full text-center relative">
        <SupplierSideMenu
          sideMenu={sideMenu}
          setSideMenu={setSideMenu}
          setSupplierDetails={setSupplierDetails}
          setAddProduct={setAddProduct}
          setUpdateInfo={setUpdateInfo}
          setDeliveryInfo={setDeliveryInfo}
          setUploadImage={setUploadImage}
          setDeleteAccount={setDeleteAccount}
          setCarts={setCarts}
          darkMode={darkMode}
        />
        <div className="flex flex-raw my-20 h-full w-full items-center justify-center">
          {supplierDetails && (
            <SupplierDetails
              supplier={data.supplier}
              products={data.products ?? []}
              inStock={inStock}
              fileInput={fileInput}
              uploadImages={uploadImages}
              deleteImages={deleteImages}
              elements={elements}
              deleteItem={deleteItem}
              handleUpdateProduct={
                handleUpdateProduct as SubmitHandler<FieldValues>
              }
              darkMode={darkMode}
            />
          )}
          {updateInfo && (
            <UpdateSupplier
              setSupplierDetails={setSupplierDetails}
              setUpdateInfo={setUpdateInfo}
              refetch={refetch}
              darkMode={darkMode}
            />
          )}
          {addProduct && (
            <AddProduct
              setSupplierDetails={setSupplierDetails}
              setAddProduct={setAddProduct}
              refetch={refetch}
              darkMode={darkMode}
            />
          )}
          {deliveryInfo && (
            <DeliveryInfo
              setSupplierDetails={setSupplierDetails}
              setDeliveryInfo={setDeliveryInfo}
              darkMode={darkMode}
            />
          )}
          {uploadImage && (
            <SupplierImage
              states={true}
              setSupplierDetails={setSupplierDetails}
              setUploadImage={setUploadImage}
            />
          )}
          {deleteAccount && (
            <DeleteSupplier darkMode={darkMode} refetch={refetch} />
          )}
          {carts && <Carts darkMode={darkMode} />}
        </div>
      </div>
    );
  }
};

export default BusinessPage;
