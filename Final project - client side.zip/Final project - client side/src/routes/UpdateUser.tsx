import { useEffect, useState } from "react";
import UpdateForm from "../components/user/UpdateForm";
import UpdateSubscription from "../components/user/UpdateSubscription";
import UpdatePassword from "../components/user/UpdatePassword";
import UploadImage from "../components/user/UserImage";
import { userServices } from "../services/user.service";
import { decodeToken } from "../utils/jwtDecode";
import { useUser } from "../hooks/useUser";
import { IUser } from "../types/models";
import DeleteUser from "../components/user/DeleteUser";
import UserSideMenu from "../components/content/UserSideMenu";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const UpdateUser = () => {
  const { darkMode } = useContext(ThemeContext);
  const { user } = useUser();
  const id = decodeToken()?.id ?? "";
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";

  const getUserImg = async () => {
    const userImg = await userServices.getUser(id);
    return userImg;
  };

  const [userImg, setUserImg] = useState<IUser | null>(null);

  useEffect(() => {
    getUserImg().then((img) => {
      if (img) setUserImg(img);
    });
  }, []);

  const [userDitails, setUserDetails] = useState(true);
  const [updateForm, setUpdateForm] = useState(false);
  const [updateSubscription, setUpdateSubscription] = useState(false);
  const [changePassword, setChangePassword] = useState(false);
  const [uploadImage, setUploadImage] = useState(false);
  const [deleteAccount, setDeleteAccount] = useState(false);

  const [sideMenu, setSideMenu] = useState(false);

  return (
    <div className="flex flex-col min-h-screen w-full text-center text-6xl">
      <UserSideMenu
        sideMenu={sideMenu}
        setSideMenu={setSideMenu}
        setUserDetails={setUserDetails}
        setUpdateForm={setUpdateForm}
        setUpdateSubscription={setUpdateSubscription}
        setChangePassword={setChangePassword}
        setUploadImage={setUploadImage}
        setDeleteAccount={setDeleteAccount}
        darkMode={darkMode}
      />
      <div className="flex flex-raw my-20 h-full w-full items-center justify-center">
        {userDitails && (
          <div className="space-y-10 ">
            <h1>My details</h1>
            <div>{user.split("User")[0]} account </div>
            <UploadImage states={false} />
            <UpdateForm states={false} darkMode={darkMode} />
          </div>
        )}
        {updateForm && <UpdateForm states={true} darkMode={darkMode} />}
        {updateSubscription && <UpdateSubscription darkMode={darkMode} />}
        {changePassword && <UpdatePassword darkMode={darkMode} />}
        {uploadImage && <UploadImage states={true} />}
        {deleteAccount && <DeleteUser />}
      </div>
    </div>
  );
};

export default UpdateUser;
