import { useQuery } from "react-query";
import { favoritesService } from "../services/favorites.service";
import { decodeToken } from "../utils/jwtDecode";
import MainSupplier from "../components/homePage/MainSuppliers";
import MainProduct from "../components/homePage/MainProducts";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import { addRemoveFavorite } from "../helpers/favorites";
import { useMutation } from "react-query";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import { showAlert } from "../utils/alert";

const Favorites = () => {
  const { darkMode } = useContext(ThemeContext);
  const userRole = decodeToken()?.role;
  const id = decodeToken()?.id;
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  const { data, isError, isLoading, refetch } = useQuery("get-favorites", () =>
    favoritesService.getUser(id, token)
  );

  const mutation = useMutation(addRemoveFavorite, {
    onSuccess: (data: any) => {
      refetch();
      showAlert("success", data.data.message, "success");
    },
  });

  const onAddToFavourites = (itemId: string, page: string) => {
    mutation.mutate({
      userRole: userRole || "",
      page: page,
      itemId: itemId,
      token: token || "",
    });
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (
    (data && data?.favoriteSupplier.length > 0) ||
    (data && data?.favoriteProduct.length > 0)
  ) {
    return (
      <div className="text-center content-center text-5xl tracking-widest font-extrabold min-h-screen">
        {data.favoriteSupplier.length > 0 && (
          <>
            <h1 className="text-4xl font-bold">My Favorites suppliers</h1>
            <div className="flex flex-wrap items-center justify-center m-10">
              {data.favoriteSupplier.map((supplier) => (
                <MainSupplier
                  supplier={supplier}
                  id={id}
                  key={supplier._id}
                  disable={true}
                  onAddToFavourites={onAddToFavourites}
                  darkMode={darkMode}
                />
              ))}
            </div>
          </>
        )}
        {data.favoriteProduct.length > 0 && (
          <>
            <h1 className="text-4xl font-bold">My Favorites products</h1>
            <div className="flex flex-wrap  justify-center m-10">
              {data.favoriteProduct.map((product) => (
                <MainProduct
                  product={product}
                  id={id}
                  key={product._id}
                  disable={true}
                  onAddToFavourites={onAddToFavourites}
                  darkMode={darkMode}
                />
              ))}
            </div>
          </>
        )}
      </div>
    );
  } else {
    return (
      <div className="text-center content-center text-5xl tracking-widest font-extrabold min-h-screen">
        <h1 className="mt-10">METROLINE</h1>
        <h2 className="mt-10">Welcome to a world of suppliers</h2>
        <h2 className="mt-10">You have no favorites yet</h2>
      </div>
    );
  }
};

export default Favorites;
