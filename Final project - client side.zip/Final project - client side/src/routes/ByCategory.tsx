import { useParams } from "react-router-dom";
import { useQuery } from "react-query";
import { webServices } from "../services/web.service";
import Loading from "../components/web/Loading";
import Error from "../components/web/Error";
import { decodeToken } from "../utils/jwtDecode";
import MainSupplier from "../components/homePage/MainSuppliers";
import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const SupplierByCategory = () => {
  const { darkMode } = useContext(ThemeContext);
  const { category } = useParams();
  const id = decodeToken()?.id ?? "guest";
  const {
    data: suppliers = [],
    error,
    isLoading,
  } = useQuery("get-suppliers", webServices.getSuppliers);

  if (!category) return <div>Category not found</div>;

  const filteredSuppliers = Array.isArray(suppliers)
    ? suppliers.filter((supplier) =>
        supplier.businessType?.type.includes(category)
      )
    : [];

  if (isLoading) return <Loading />;
  if (error) return <Error />;
  if (filteredSuppliers.length === 0)
    return (
      <div className="flex justify-center text-4xl">
        Sorry, there are no suppliers yet in this category
      </div>
    );
console.log(id)
  return (
    <div className="flex flex-wrap items-center justify-center m-10 text-center  text-5xl tracking-widest font-extrabold">
      {filteredSuppliers.map((supplier) => (
        <MainSupplier
          supplier={supplier}
          darkMode={darkMode}
          id={id}
          key={supplier._id}
        />
      ))}
    </div>
  );
};

export default SupplierByCategory;
