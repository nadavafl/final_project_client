import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebook } from "@fortawesome/free-brands-svg-icons";
import { faInstagram } from "@fortawesome/free-brands-svg-icons";
import { faTwitter } from "@fortawesome/free-brands-svg-icons";
import { faLinkedin } from "@fortawesome/free-brands-svg-icons";
import { showAlert } from "../utils/alert";
import { useState } from "react";

const Footer = () => {
  const [newsletter, setNewsletter] = useState("");

  const linkStyle =
    "flex w-36 border-transparent border-x-2 hover:border-current hover:text-yellow-300";
  return (
    <footer className="flex bg-gray-800 w-full p-5 text-white text-center text-2xl">
      <div className="flex flex-col w-full xl:w-1/4 lg:w-1/3 md:w-1/2 sm:w-3/4 mx-auto gap-5">
        <Link className={linkStyle} to="/aboutUs">
          About Us
        </Link>
        <Link className={linkStyle} to="/advertise">
          Advertising
        </Link>
        <Link className={linkStyle} to="/contact">
          Contact
        </Link>
        <Link className={linkStyle} to="/joinUs">
          Join Us
        </Link>
      </div>
      <div className="relative mx-44">
        <p className=" flex font-bold ">© 2024 METROLINE by Nadav Aflalo</p>
        <div className="flex flex-raw items-center justify-center gap-5 text-5xl absolute bottom-0 right-16">
          <Link to="https://www.facebook.com" target="_blank" rel="noreferrer">
            <FontAwesomeIcon icon={faFacebook} />
          </Link>
          <Link to="https://www.instagram.com" target="_blank" rel="noreferrer">
            <FontAwesomeIcon icon={faInstagram} />
          </Link>
          <Link to="https://www.twitter.com" target="_blank" rel="noreferrer">
            <FontAwesomeIcon icon={faTwitter} />
          </Link>
          <Link to="https://www.linkedin.com" target="_blank" rel="noreferrer">
            <FontAwesomeIcon icon={faLinkedin} />
          </Link>
        </div>
      </div>
      <div className="flex flex-col w-full xl:w-1/4 lg:w-1/3 md:w-1/2 sm:w-3/4 mx-auto gap-5">
        <p className="text-lg">Join our newsletter</p>
        <input
          className="p-2 rounded-md text-black text-3xl"
          type="email"
          placeholder="Enter your email"
          onChange={(e) => setNewsletter(e.target.value)}
          value={newsletter} // use value prop instead of defaultValue
        />
        <button
          className="bg-yellow-300 p-2 rounded-md text-3xl font-bold"
          onClick={() => {
            setNewsletter("");
            showAlert(
              "success",
              "Thank you for joining our newsletter",
              "success"
            );
          }}
        >
          Join
        </button>
      </div>
    </footer>
  );
};

export default Footer;
