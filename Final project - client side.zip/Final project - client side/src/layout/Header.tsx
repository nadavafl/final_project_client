import { useNavigate } from "react-router-dom";
import avatarPlaceholder from "../img/avatarPlaceholder.png";
import { FormEvent, useContext, useEffect, useState } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import { showAlert } from "../utils/alert";
import { useUser } from "../hooks/useUser";
import { decodeToken } from "../utils/jwtDecode";
import { ImageContext } from "../contexts/ImageContext";
import { userServices } from "../services/user.service";
import NonGuestHeader from "../components/header/NonGuestHeader";
import GuestHeader from "../components/header/GuestHeader";

const Header = () => {
  const [searchInput, setSearchInput] = useState("");
  const [avatarDropdown, setAvatarDropdown] = useState(false);
  const [cartDropdown, setCartDropdown] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [userName, serUserName] = useState("Guest");
  const [isOpen, setIsOpen] = useState(false);
  const { darkMode, toggleDarkMode } = useContext(ThemeContext);
  const { user, setUser } = useUser();
  const id = decodeToken()?.id ?? "";
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  const { userImg, setUserImg } = useContext(ImageContext);
  const navigate = useNavigate();

  const logOut = () => {
    setAvatarDropdown(!avatarDropdown);
    setUser("guest");
    sessionStorage.removeItem("token");
    showAlert("info", "Logged out successfully", "info");
  };

  useEffect(() => {
    const imageData = async () => {
      let token = sessionStorage.getItem("token");
      token = token ? JSON.parse(token) : "guest";
      const id = decodeToken()?.id ?? "";
      if (!user || user === "guest" || !id || !token) return;
      const data = await userServices.getUser(id);
      if (data) {
        const imageBuffer = data.image?.file.data.data;
        const blob = new Blob([new Uint8Array(imageBuffer)], {
          type: data.image?.file.contentType,
        });
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = function () {
          setUserImg(reader.result as string);
          setUserEmail(data.email);
          serUserName(data.name.first);
        };
      }
    };
    imageData();
  }, [user]); // Add user as a dependency

  const handleSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    navigate(`/search/${searchInput}`);
    setSearchInput("");
  };

  const line = <p className="text-yellow-200">~line</p>;
  const userImage = userImg ? userImg : avatarPlaceholder;

  if (user && user !== "guest") {
    return (
      <NonGuestHeader
        id={id}
        line={line}
        handleSearch={handleSearch}
        searchInput={searchInput}
        setSearchInput={setSearchInput}
        toggleDarkMode={toggleDarkMode}
        darkMode={darkMode}
        setAvatarDropdown={setAvatarDropdown}
        avatarDropdown={avatarDropdown}
        userImage={userImage}
        userEmail={userEmail}
        logOut={logOut}
        user={user}
        userName={userName}
        setCartDropdown={setCartDropdown}
        cartDropdown={cartDropdown}
      />
    );
  } else {
    return (
      <GuestHeader
        id={id}
        line={line}
        handleSearch={handleSearch}
        searchInput={searchInput}
        setSearchInput={setSearchInput}
        toggleDarkMode={toggleDarkMode}
        darkMode={darkMode}
        user={user}
        setIsOpen={setIsOpen}
        isOpen={isOpen}
      />
    );
  }
};

export default Header;
