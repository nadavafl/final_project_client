import Footer from "./Footer";
import Header from "./Header";

const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="flex flex-col flex-wrap min-h-screen">
      <Header />
      <main className="mb-10 mt-10">{children}</main>
      <Footer />
    </div>
  );
};

export default Layout;
