import AdminNavbar from "../components/navbar/AdminNavbar";
import SubscriberNavbar from "../components/navbar/SubscriberNavbar";
import GuestNavbar from "../components/navbar/GuestNavbar";

const linkStyle =
  "flex border-transparent border-x-2 hover:border-current hover:text-yellow-300 px-3";
const Navbar = ({ user, userName }: { user: string; userName?: string }) => {
  if (user && user === "Admin") {
    return <AdminNavbar linkStyle={linkStyle} userName={userName} />;
  }
  if ((user && user === "Subscriber") || user === "BusinessUser") {
    return (
      <SubscriberNavbar linkStyle={linkStyle} userName={userName} user={user} />
    );
  }
  if (user && user === "guest") {
    return <GuestNavbar linkStyle={linkStyle} />;
  }
};

export default Navbar;
