import axios from "axios";
import { useMutation } from "react-query";
import { showAlert } from "../utils/alert";

export const useHideCart = (token: string | null, refetch: () => void) => {
  return useMutation(
    (params: { userId: string; invoiceId: string }) =>
      axios.patch(
        `http://localhost:8080/api/v1/cart/hideCart/${params.userId}/${params.invoiceId}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      ),
    {
      onSuccess: () => {
        refetch();
        showAlert("success", "Cart removed successfully", "success");
      },
      onError: (error) => {
        console.error(error);
      },
    }
  );
};
