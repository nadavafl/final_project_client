import { UseMutationResult, useMutation } from "react-query";
import { productService } from "../services/product.service";
import { supplierServices } from "../services/supplier.service";

export const useHandleLike = ({
  id,
  refetch,
  type,
}: {
  id: string | undefined;
  refetch: () => void;
  type: "Supplier" | "Product";
}) => {
  let mutation: UseMutationResult<any, unknown, void, unknown>;

  if (type === "Product") {
    mutation = useMutation(() => productService.likeProduct(id ?? ""), {
      onSuccess: () => {
        refetch();
      },
    });
  } else if (type === "Supplier") {
    mutation = useMutation(() => supplierServices.likeSupplier(id ?? ""), {
      onSuccess: () => {
        refetch();
      },
    });
  }

  const handleLike = () => {
    mutation?.mutate();
  };

  return { handleLike };
};
