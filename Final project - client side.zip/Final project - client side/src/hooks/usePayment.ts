import { cartAlerts } from "./../helpers/cartAlerts";
import axios from "axios";
import { useMutation } from "react-query";

export const usePayment = (token: string | null, refetch: () => void) => {
  return useMutation(
    async (params: { userId: string; supplierId: string }) => {
      await axios.patch(
        `http://localhost:8080/api/v1/cart/checkout/${params.userId}/${params.supplierId}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    },
    {
      onSuccess: () => {
        refetch();
        cartAlerts.payment();
      },
      onError: (error) => {
        console.error(error);
      },
    }
  );
};
