import axios from "axios";
import { useMutation } from "react-query";
import { cartAlerts } from "../helpers/cartAlerts";

export const useDeleteCart = (token: string | null, refetch: () => void) => {
  return useMutation(
    (params: { cartId: string; userId: string }) =>
      axios.delete(
        `http://localhost:8080/api/v1/cart/delete/${params.userId}/${params.cartId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      ),
    {
      onSuccess: () => {
        refetch();
        cartAlerts.deleteCart();
      },
      onError: (error) => {
        console.error(error);
      },
    }
  );
};
