// User provider
import React, { createContext, useContext, ReactNode } from "react";

interface UserContextType {
  user: string;
  setUser: React.Dispatch<React.SetStateAction<string>>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

interface UserProviderProps {
  children: ReactNode;
  value: UserContextType;
}

export const UserProvider: React.FC<UserProviderProps> = ({
  children,
  value,
}) => {
  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

// useUser hook
export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
};
