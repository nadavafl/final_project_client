import { cartAlerts } from "./../helpers/cartAlerts";
import axios from "axios";
import { useMutation } from "react-query";

export const useRemoveItem = (token: string | null, refetch: () => void) => {
  return useMutation(
    async (params: {
      userId: string;
      supplierId: string;
      productId: string;
    }) => {
      await axios.post(
        `http://localhost:8080/api/v1/cart/remove/${params.userId}/${params.supplierId}`,
        {
          _id: params.productId,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return params;
    },
    {
      onSuccess: () => {
        refetch();
        cartAlerts.removeItem();
      },
      onError: (error) => {
        console.error(error);
      },
    }
  );
};
