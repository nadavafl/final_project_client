import { SubmitHandler, FieldValues } from "react-hook-form";
import { productService } from "../services/product.service";
import { showAlert } from "../utils/alert";

export const useBusinessPageHandlers = (id: string, refetch: () => void) => {
  const elements = ["title", "description", "price", "stock", "product_number"];
  type SubmitHandlerWithIndex = SubmitHandler<FieldValues> & {
    [key: string]: FieldValues;
  };

  const handleUpdateProduct = async (formData: SubmitHandlerWithIndex) => {
    for (const productId in formData) {
      elements.forEach(async (element) => {
        const value = formData[productId][element];
        if (value) {
          const productInput: any = { [element]: value };
          const response = await productService.updatingProduct(
            id,
            productId,
            productInput
          );
          showAlert("success", response.message, "success");
          await refetch();
        }
      });
    }
  };

  const inStock = async (event: React.MouseEvent, productId: string) => {
    event.preventDefault();
    const response = await productService.updateInStock(id, productId);
    showAlert("success", response.message, "success");
    await refetch();
  };

  const deleteItem = async (event: React.MouseEvent, productId: string) => {
    event.preventDefault();
    const response = await productService.deleteProduct(id, productId);
    showAlert("success", response.message, "success");
    await refetch();
  };

  const uploadImages = async (event: any, productId: string) => {
    event.preventDefault();
    const file = event.target.files[0];
    const response = await productService.uploadImage(productId, file);
    showAlert("success", response.message, "success");
    await refetch();
  };

  const deleteImages = async (
    event: React.MouseEvent,
    productId: string,
    imageId: string
  ) => {
    event.preventDefault();
    const response = await productService.deleteImage(productId, imageId);
    showAlert("success", response.message, "success");
    await refetch();
  };

  return {
    handleUpdateProduct,
    inStock,
    deleteItem,
    uploadImages,
    deleteImages,
  };
};
