import axios from "axios";
import { useMutation } from "react-query";
import { supplierAlerts } from "../helpers/supplierAlerts";
import { useNavigate } from "react-router-dom";

const processedCombinations = new Set<string>();

export const useIncrementItem = (token: string | null, refetch: () => void) => {
  const navigate = useNavigate();
  const selectedProduct = JSON.parse(
    sessionStorage.getItem("selectedProduct")!
  );

  return useMutation(
    (params: {
      userId: string;
      supplierId: string;
      productId: string;
      quantity: number;
    }) =>
      axios.post(
        `http://localhost:8080/api/v1/cart/add/${params.userId}/${params.supplierId}`,
        {
          _id: params.productId,
          quantity: params.quantity,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      ),
    {
      onSuccess: (data, params) => {
        refetch();
        const combination = `${params.userId}-${params.supplierId}`;
        if (!processedCombinations.has(combination)) {
          supplierAlerts.response(data.data.message, selectedProduct, navigate);
          processedCombinations.add(combination);
        }
      },
      onError: (error) => {
        console.error(error);
      },
    }
  );
};
