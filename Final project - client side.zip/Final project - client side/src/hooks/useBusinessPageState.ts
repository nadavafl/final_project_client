import { useState, useEffect } from "react";

export const useBusinessPageState = () => {
  const [supplierDetails, setSupplierDetails] = useState(true);
  const [addProduct, setAddProduct] = useState(false);
  const [updateInfo, setUpdateInfo] = useState(false);
  const [deliveryInfo, setDeliveryInfo] = useState(false);
  const [uploadImage, setUploadImage] = useState(false);
  const [deleteAccount, setDeleteAccount] = useState(false);
  const [carts, setCarts] = useState(false);

  useEffect(() => {
    if (
      updateInfo ||
      deliveryInfo ||
      uploadImage ||
      deleteAccount ||
      addProduct ||
      carts
    ) {
      setSupplierDetails(false);
    }
  }, [updateInfo, deliveryInfo, uploadImage, deleteAccount, addProduct, carts]);

  return {
    supplierDetails,
    addProduct,
    updateInfo,
    deliveryInfo,
    uploadImage,
    deleteAccount,
    carts,
    setSupplierDetails,
    setAddProduct,
    setUpdateInfo,
    setDeliveryInfo,
    setUploadImage,
    setDeleteAccount,
    setCarts,
  };
};
