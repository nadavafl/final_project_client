import "./App.css";
import Layout from "./layout/Layout";
import { QueryClient, QueryClientProvider } from "react-query";
import { useEffect, useState } from "react";
import { UserProvider } from "./hooks/useUser";
import { decodeToken } from "./utils/jwtDecode";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ImageContext } from "./contexts/ImageContext";
import { AppRoutes } from "./routes/AppRoutes";

function App() {
  const [user, setUser] = useState<string>("guest");
  const [userImg, setUserImg] = useState("");
  const [supplierImg, setSupplierImg] = useState("");

  useEffect(() => {
    const tokenRole = decodeToken()?.role;
    setUser(tokenRole || "guest");
  }, []);

  const queryClient = new QueryClient();
  return (
    <>
      <QueryClientProvider client={queryClient}>
        <UserProvider value={{ user, setUser }}>
          <ThemeProvider>
            <ImageContext.Provider
              value={{ userImg, setUserImg, supplierImg, setSupplierImg }}
            >
              <Layout>
                <AppRoutes />
              </Layout>
            </ImageContext.Provider>
          </ThemeProvider>
        </UserProvider>
      </QueryClientProvider>
    </>
  );
}

export default App;
