import { buffer } from "node:stream/consumers";
import mongoose from "mongoose";

export type IRole = {
  name: string;
};

export type IAddress = {
  country: string;
  state?: string;
  city: string;
  street: string;
  houseNumber: string;
  postalCode?: string;
};

export type IImage = {
  _id?: string;
  fileName: string;
  file: buffer | string;
  default?: data | string;
  uploadTime?: Date;
};

export type IUserInput = {
  role?: {
    name: string;
  };
  name: {
    first: string;
    middle: string;
    last: string;
  };
  phone: string;
  email: string;
  password?: string;
  repeatPassword?: string;
  address: {
    country: string;
    state: string;
    city: string;
    street: string;
    houseNumber: string;
    postalCode: string;
  };
};

export type IUser = IUserInput & {
  image?: IImage;
  favoriteSupplier: object[];
  favoriteProduct: object[];
  _id?: string;
  [key: string]: {};
};

export type IBusinessType = {
  type: string;
};

export type IOrderDetail = {
  minOrder: number | string;
  deliveryAreaDays: string;
  deliveryCost: number | string;
};

export type ISupplierInput = {
  _id?: string;
  businessType?: IBusinessType;
  businessTypeValue?: string;
  title: string;
  subtitle: string;
  description: string;
  phone: string;
  email: string;
  web: string;
  address: IAddress;
  orderDetail?: IOrderDetail;
};

export type ISupplier = ISupplierInput & {
  image?: IImage;
  bizNumber?: number;
  likes?: string[];
  user_id?: string;
  createdAt?: Date;
};

export type ILogin = {
  email: string;
  password: string;
};

export type ICartItem = {
  _id: string;
  title: string;
  quantity: number;
  price: number;
};

export type ICartInvoice = {
  _id: string;
  items: ICartItem[];
  total: number;
};

export type ICart = {
  _id: string;
  customer_id: string;
  supplier_id: string;
  supplier_name: string;
  items: ICartItem[];
  cartQuantity: number;
  total: number;
  isPaid: boolean;
  paidAt: Date;
  invoice: ICartInvoice;
  isDelivered: boolean;
  deliveredAt: Date;
  hideCart: boolean;
};

export type IPaidCarts = {
  paidCarts: ICart[];
  unpaidCarts: ICart[];
};

export type IProductInput = {
  product_number: string;
  title: string;
  description: string;
  inStock: boolean;
  stock?: number;
  price: number;
  images: IImage[];
};

export type IProduct = IProductInput & {
  _id: string;
  likes: string[];
  supplier_id: string;
  createdAt?: Date;
};

// export type IContactInfo = {
//   name: string;
//   phone: string;
//   email: string;
// };

// export type IAdvertisingInput = {
//   contactInfo: IContactInfo;
//   linkTo: string;
//   images: IImage[];
// };

// export type IAdvertising = IAdvertisingInput & {
//   createdByUser_id: string;
//   clicks: string[];
//   isActive: boolean;
//   isApproved: boolean;
//   isPaid: boolean;
//   paidAt: Date;
// };

export type ISearch = {
  categories: string[];
  suppliersInfo: ISupplier[];
  productsInfo: IProduct[];
};
