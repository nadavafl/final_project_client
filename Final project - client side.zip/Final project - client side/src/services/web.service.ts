import { IBusinessType, IProduct, ISupplier } from "../types/models";
import axios from "axios";
import { urlConstants } from "../constants/url.constants";

const getSuppliers = async () => {
  try {
    const response = await axios.get(urlConstants.supplierUrl);
    return response.data as ISupplier[];
  } catch (error) {
    throw error;
  }
};

const getcategories = async () => {
  try {
    const response = await axios.get(urlConstants.categoriesUrl);
    return response.data as IBusinessType[];
  } catch (error) {
    throw error;
  }
};

const getProduct = async () => {
  try {
    const response = await axios.get(urlConstants.productUrl);
    return response.data as IProduct[];
  } catch (error) {
    throw error;
  }
};

const getSupplierProducts = async (supplierId: string) => {
  try {
    const response = await axios.get(
      `${urlConstants.webSupProductsUrl}/${supplierId}`
    );
    return response.data as IProduct[];
  } catch (error) {
    throw error;
  }
};

export const webServices = {
  getSuppliers,
  getcategories,
  getProduct,
  getSupplierProducts,
};
