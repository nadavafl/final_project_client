import axios from "axios";
import { IPaidCarts } from "../types/models";
import { urlConstants } from "../constants/url.constants";

let token = sessionStorage.getItem("token");
token = token ? JSON.parse(token) : "";

const getUserCart = async (
  userId: string | undefined,
  token: string | null
) => {
  try {
    if (userId === "guest") return;
    const response = await axios.get<IPaidCarts>(
      `${urlConstants.userCartUrl}/myCarts/${userId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    const paidCarts = response.data.paidCarts;
    const unpaidCarts = response.data.unpaidCarts;
    return { paidCarts, unpaidCarts };
  } catch (error) {
    throw error;
  }
};

const getAllCartsBySupplier = async (supplierId: string | undefined) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  try {
    const response = await axios.get(
      `${urlConstants.userCartUrl}/supplierCarts/${supplierId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

const approveDelivery = async (
  supplierId: string | undefined,
  cartId: string,
  customerId: string | undefined
) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  try {
    const response = await axios.patch(
      `${urlConstants.userCartUrl}/delivery/${customerId}/${supplierId}/${cartId}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};


const deleteCart = async (
  userId: string | undefined,
  cartId: string | undefined,
) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  try {
    const response = await axios.delete(
      `${urlConstants.userCartUrl}/delete/${userId}/${cartId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const cartService = {
  getUserCart,
  getAllCartsBySupplier,
  approveDelivery,
  deleteCart,
};
