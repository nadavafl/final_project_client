import axios from "axios";
import { ISearch } from "../types/models";
import { urlConstants } from "../constants/url.constants";

const GeneralSearch = async (searchInput: string) => {
  try {
    const response = await axios.get(urlConstants.searchUrl + searchInput);
    return response.data as ISearch;
  } catch (error: any) {
    throw error;
  }
};

export const searchService = {
  GeneralSearch,
};
