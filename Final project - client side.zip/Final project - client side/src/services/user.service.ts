import axios from "axios";
import { IUser, IUserInput } from "../types/models";
import { urlConstants } from "../constants/url.constants";

let token = sessionStorage.getItem("token");
token = token ? JSON.parse(token) : "guest";

const registerUser = async (newUser: IUserInput) => {
  try {
    const response = await axios.post(urlConstants.registerUserUrl, newUser);
    return response.data as IUserInput;
  } catch (error: any) {
    throw error;
  }
};

const getUser = async (userId: string | undefined) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  if (!token) return;
  try {
    const response = await axios.get(`${urlConstants.userUrl}/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data as IUser;
  } catch (error: any) {
    throw error;
  }
};

const updateUser = async (userId: string | undefined, newData: IUserInput) => {
  try {
    const response = await axios.put(
      `${urlConstants.userUrl}/${userId}`,
      { ...newData },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data as IUserInput;
  } catch (error: any) {
    throw error;
  }
};

const changeRole = async (userId: string, newRole: IUserInput) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  try {
    const response = await axios.patch(
      `${urlConstants.userUrl}/${userId}`,
      { role: { ...newRole.role } },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data as IUserInput;
  } catch (error: any) {
    throw error;
  }
};

const uploadImage = async (userId: string, file: File) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  const formData = new FormData();
  formData.append("file", file);
  formData.append("fileName", file.name);
  try {
    const response = await axios.post(
      `${urlConstants.uploadImageUrl}/${userId}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

const deleteImage = async (userId: string) => {
  try {
    const response = await axios.delete(
      `${urlConstants.deleteImageUrl}/${userId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

const deleteUser = async (userId: string) => {
  try {
    const response = await axios.delete(`${urlConstants.userUrl}/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

export const userServices = {
  registerUser,
  getUser,
  updateUser,
  changeRole,
  uploadImage,
  deleteImage,
  deleteUser,
};
