import axios from "axios";
import { ICart, ISupplier, IUser } from "../types/models";
import { urlConstants } from "../constants/url.constants";

const getUsers = async (token: string) => {
  try {
    const response = await axios.get(urlConstants.userUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data as IUser[];
  } catch (error) {
    throw error;
  }
};

const getSuppliers = async () => {
  try {
    const response = await axios.get(urlConstants.supplierUrl);
    return response.data as ISupplier[];
  } catch (error) {
    throw error;
  }
};

const getCarts = async (token: string) => {
  try {
    const response = await axios.get(urlConstants.cartUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data as ICart[];
  } catch (error) {
    throw error;
  }
};

export const adminServices = {
  getUsers,
  getSuppliers,
  getCarts,
};
