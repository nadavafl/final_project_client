import { IOrderDetail } from "../types/models";
import {
  IBusinessType,
  IProduct,
  ISupplier,
  ISupplierInput,
} from "../types/models";
import axios from "axios";
import { urlConstants } from "../constants/url.constants";

let token = sessionStorage.getItem("token");
token = token ? JSON.parse(token) : "";

const registerSupplier = async (supplier: ISupplier) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  try {
    const response = await axios.post(urlConstants.supplierUrl, supplier, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data as ISupplier;
  } catch (error: any) {
    throw error;
  }
};

const getBusinessTypes = async () => {
  try {
    const response = await axios.get(`${urlConstants.supplierUrl}/types`);
    return response.data as IBusinessType[];
  } catch (error: any) {
    throw error;
  }
};

const myBusinesses = async () => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  try {
    const response = await axios.get(urlConstants.myBusinessesUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data as ISupplier[];
  } catch (error: any) {
    throw error;
  }
};

const deleteSupplier = async (id: string) => {
  try {
    const response = await axios.delete(`${urlConstants.supplierUrl}/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

const getSupplierById = async (id: string) => {
  try {
    const response = await axios.get(
      `${urlConstants.supplierUrl}/business/${id}`
    );
    const data = response.data as ISupplier;
    return data;
  } catch (error: any) {
    throw error;
  }
};

const getproducts = async (supplierId: string) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  try {
    const response = await axios.get(
      `${urlConstants.supplierProductsUrl}/${supplierId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data as IProduct[];
  } catch (error: any) {
    throw error;
  }
};

const uploadImage = async (
  supplierId: string,
  token: string | null,
  file: File
) => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("fileName", file.name);
  try {
    const response = await axios.post(
      `${urlConstants.supplierUrl}/uploadImage/${supplierId}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

const deleteImage = async (id: string) => {
  try {
    const response = await axios.delete(
      `${urlConstants.supplierUrl}/deleteImage/${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

const updateSupplierInfo = async (
  supplierId: string,
  deliveryInfo: ISupplierInput | IOrderDetail
) => {
  try {
    const response = await axios.put(
      `${urlConstants.supplierUrl}/${supplierId}`,
      deliveryInfo,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

const likeSupplier = async (supplierId: string) => {
  try {
    const response = await axios.patch(
      `${urlConstants.supplierUrl}/${supplierId}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    throw error;
  }
};

export const supplierServices = {
  registerSupplier,
  getBusinessTypes,
  myBusinesses,
  getSupplierById,
  deleteSupplier,
  getproducts,
  uploadImage,
  deleteImage,
  updateSupplierInfo,
  likeSupplier,
};
