import axios from "axios";
import { IProduct, ISupplier, IUser } from "../types/models";
import { urlConstants } from "../constants/url.constants";

const getUser = async (userId: string | undefined, token: string | null) => {
  try {
    const response = await axios.get<IUser>(
      `${urlConstants.userUrl}/${userId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    const favoriteSupplier = response.data.favoriteSupplier as ISupplier[];
    const favoriteProduct = response.data.favoriteProduct as IProduct[];
    return { favoriteSupplier, favoriteProduct };
  } catch (error) {
    throw error;
  }
};

export const favoritesService = {
  getUser,
};
