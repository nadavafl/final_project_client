import axios from "axios";
import { IProduct, IProductInput } from "../types/models";
import { urlConstants } from "../constants/url.constants";

let token = sessionStorage.getItem("token");
token = token ? JSON.parse(token) : "";

const getProductById = async (productId: string) => {
  try {
    const response = await axios.get(`${urlConstants.productUrl}/${productId}`);
    return response.data as IProduct;
  } catch (error) {
    throw error;
  }
};

const updateInStock = async (supplierId: string, productId: string) => {
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  try {
    const response = await axios.patch(
      `${urlConstants.productUrl}/supplier/updateInStock/${supplierId}/${productId}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

const deleteProduct = async (supplierId: string, productId: string) => {
  try {
    const response = await axios.delete(
      `${urlConstants.productUrl}/supplier/deleteProduct/${supplierId}/${productId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

const updatingProduct = async (
  supplierId: string,
  productId: string,
  product: IProductInput
) => {
  try {
    const response = await axios.put(
      `${urlConstants.productUrl}/supplier/updateProduct/${supplierId}/${productId}`,
      product,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

const uploadImage = async (productId: string, file: File) => {
  try {
    const formData = new FormData();
    formData.append("file", file);
    const response = await axios.post(
      `${urlConstants.productUrl}/supplier/uploadImage/${productId}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

const deleteImage = async (productId: string, imageId: string) => {
  try {
    const response = await axios.delete(
      `${urlConstants.productUrl}/supplier/deleteImage/${productId}/${imageId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

const addProduct = async (supplierId: string, product: IProductInput) => {
  try {
    const response = await axios.post(
      `${urlConstants.productUrl}/${supplierId}`,
      product,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
}; 

const likeProduct = async (productId: string) => {
  try {
    const response = await axios.patch(
      `${urlConstants.productUrl}/${productId}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const productService = {
  getProductById,
  updateInStock,
  deleteProduct,
  updatingProduct,
  uploadImage,
  deleteImage,
  addProduct,
  likeProduct,
};
