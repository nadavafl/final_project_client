import { IUserInput } from "../types/models";

export const UserValues: IUserInput = {
  name: {
    first: "First name",
    middle: "Middle name",
    last: "Last name",
  },
  phone: "Phone number",
  email: "Email",
  address: {
    country: "Country",
    state: "State",
    city: "City",
    street: "Street",
    houseNumber: "House number",
    postalCode: "Postal code",
  },
};
