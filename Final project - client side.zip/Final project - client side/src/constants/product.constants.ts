export const elements = [
  "title",
  "description",
  "price",
  "stock",
  "product_number",
];

export const fieldDisplayNames = {
  title: "Title",
  description: "Desc",
  price: "Price",
  stock: "Stock",
  product_number: "P.num",
};
