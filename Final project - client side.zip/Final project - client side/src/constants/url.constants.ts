const userUrl = "http://localhost:8080/api/v1/users";
const supplierUrl = "http://localhost:8080/api/v1/suppliers";
const cartUrl = "http://localhost:8080/api/v1/cart/allCarts";
const userCartUrl = "http://localhost:8080/api/v1/cart";
const searchUrl = "http://localhost:8080/api/v1/search?q=";
const myBusinessesUrl = "http://localhost:8080/api/v1/suppliers/MyBusinesses";
const supplierProductsUrl =
    "http://localhost:8080/api/v1/product/supplier/myProducts";
const registerUserUrl = "http://localhost:8080/api/v1/users/register";
const uploadImageUrl = "http://localhost:8080/api/v1/users/uploadImage";
const deleteImageUrl = "http://localhost:8080/api/v1/users/deleteImage";
const categoriesUrl = "http://localhost:8080/api/v1/suppliers/types";
const productUrl = "http://localhost:8080/api/v1/product";
const webSupProductsUrl =
  "http://localhost:8080/api/v1/product/supplierProducts";


export const urlConstants = {
    userUrl,
    supplierUrl,
    cartUrl,
    userCartUrl,
    searchUrl,
    myBusinessesUrl,
    supplierProductsUrl,
    registerUserUrl,
    uploadImageUrl,
    deleteImageUrl,
    categoriesUrl,
    productUrl,
    webSupProductsUrl,
};
    