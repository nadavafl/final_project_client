import { ISupplier } from "../types/models";

export const supplierValues: ISupplier = {
  businessTypeValue: "Business type",
  title: "Title",
  subtitle: "Subtitle",
  description: "Description",
  phone: "Phone number",
  email: "Email",
  web: "Website",
  address: {
    country: "Country",
    state: "State",
    city: "City",
    street: "Street",
    houseNumber: "House number",
    postalCode: "Postal code",
  },
  orderDetail: {
    minOrder: "minOrder",
    deliveryAreaDays: "Delivery area days",
    deliveryCost: "deliveryCost",
  },
};
