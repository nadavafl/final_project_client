import { JwtPayload, jwtDecode } from "jwt-decode";

export function decodeToken() {
  const token = sessionStorage.getItem("token");
  if (!token) return;
  try {
    const parsedToken = JSON.parse(token);
    const decoded = jwtDecode<JwtPayload>(parsedToken);
    return decoded as { id: string; role: string };
  } catch (err) {
    console.error("Failed to decode token", err);
  }
}
