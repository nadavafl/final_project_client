import Swal, { SweetAlertIcon, SweetAlertPosition } from "sweetalert2";

const isHTML = (str: string) => {
  const doc = new DOMParser().parseFromString(str, "text/html");
  return Array.from(doc.body.childNodes).some((node) => node.nodeType === 1);
};

export function showAlert(
  title: string,
  text: string,
  icon: SweetAlertIcon = "info",
  confirmButtonText: string = "OK",
  position: SweetAlertPosition = "center",
  showConfirmButton: boolean = true,
  navigate?: (path: string) => void,
  button?: string
) {
  if (!isHTML(text)) {
    Swal.fire({
      title,
      text,
      icon,
      confirmButtonText,
      position,
      showConfirmButton,
      html: button,
    });

    const goToCartButton = document.getElementById("goToCartButton");
    if (goToCartButton) {
      goToCartButton.addEventListener("click", () => {
        if (navigate) {
          navigate("/Mycarts"); 
        }
        Swal.close();
      });
    }

    const continueShoppingButton = document.getElementById(
      "continueShoppingButton"
    );
    if (continueShoppingButton) {
      continueShoppingButton.addEventListener("click", () => {
        Swal.close();
      });
    }
  }
}
