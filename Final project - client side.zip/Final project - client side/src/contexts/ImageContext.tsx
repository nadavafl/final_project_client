import { createContext } from "react";

export const ImageContext = createContext({
  userImg: "",
  setUserImg: (src: string) => {},
  supplierImg: "",
  setSupplierImg: (src: string) => {},
});
