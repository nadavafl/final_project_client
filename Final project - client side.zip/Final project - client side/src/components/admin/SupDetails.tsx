import { ISupplier } from "../../types/models";

const SupDetails = ({ supplier }: { supplier: ISupplier }) => {
  return (
    <>
      <h1 className="flex justify-center">{supplier.title}</h1>
      <div>
        <h2 className="text-center my-10">{supplier.businessType?.type}</h2>
        <div className="space-y-6">
          <p>Business num: {supplier.bizNumber}</p>
          <p>Email: {supplier.email}</p>
          <p>Phone: {supplier.phone}</p>
          <p>Website: {supplier.web}</p>
          <p>
            {supplier.address.country} {supplier.address.state}{" "}
            {supplier.address.city} {supplier.address.street}{" "}
            {supplier.address.houseNumber} {supplier.address.postalCode}
          </p>
        </div>
      </div>
    </>
  );
};

export default SupDetails;
