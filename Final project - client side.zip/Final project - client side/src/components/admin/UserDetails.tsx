import { IUser } from "../../types/models";

const UserDetails = ({ user }: { user: IUser }) => {
  return (
    <>
      <div className="flex flex-col space-y-4 text-center mt-10 text-2xl">
        <h1>{user.name.first}</h1>
        <h1>{user.name.middle}</h1>
        <h1>{user.name.last}</h1>
      </div>
      <h2 className="text-center my-10">{user.role?.name}</h2>
      <div className="space-y-6">
        <p>Id: {user._id}</p>
        <p>Email: {user.email}</p>
        <p>Phone: {user.phone}</p>
        <p>
          {user.address.country} {user.address.state} {user.address.city}{" "}
          {user.address.street} {user.address.houseNumber}{" "}
          {user.address.postalCode}
        </p>
      </div>
    </>
  );
};

export default UserDetails;
