import { useState } from "react";
import { ISupplier } from "../../types/models";
import DeleteSupplier from "../supplier/DeleteSupplier";
import SupContolMenu from "./SupControlMenu";
import SupDetails from "./SupDetails";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmark } from "@fortawesome/free-solid-svg-icons";

const SuppliersList = ({
  suppliers,
  refetch,
  darkMode,
}: {
  suppliers: ISupplier[] | undefined;
  refetch: () => void;
  darkMode: boolean | any;
}) => {
  const [choosenItem, setChoosenItem] = useState<ISupplier | null>(null);
  const [editBtn, setEditBtn] = useState<Record<string, boolean>>({});
  const [update, setUpdate] = useState("");
  const toggleEditBtn = (id: string) => {
    setEditBtn((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div>
      {choosenItem && (
        <div className="overlay">
          <div
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="fullInfoAdmin bg-slate-300 relative"
          >
            {update === "delete" && (
              <DeleteSupplier
                suppliers={choosenItem}
                setChoosenItem={setChoosenItem}
                refetch={refetch}
                darkMode={darkMode}
              />
            )}
            <button
              className="bg-red-500 text-white p-2 rounded-md absolute top-1 right-1 text-2xl hover:bg-red-700 w-1/12"
              onClick={async () => setChoosenItem(null)}
            >
              <FontAwesomeIcon icon={faXmark} />
            </button>
          </div>
        </div>
      )}
      {suppliers?.length ? (
        <div>
          <h1 className="flex justify-center">Suppliers`s List</h1>
          <div className="flex flex-wrap items-center justify-center m-10">
            {suppliers?.map((supplier) => (
              <div
                className="flex flex-row items-center justify-center w-full min-h-full sm:w-1/2 md:w-1/3 lg:w-1/2 xl:w-1/3"
                key={supplier._id}
              >
                <div
                  style={{ backgroundColor: darkMode && "#1f2937" }}
                  id="card"
                  className="flex flex-col m-3 p-3 text-2xl min-h-full w-3/4 relative rounded-xl"
                >
                  <div className="flex flex-col text-left font-bold mt-10 w-full">
                    <SupDetails supplier={supplier} />
                    <SupContolMenu
                      supplier={supplier}
                      editBtn={editBtn}
                      toggleEditBtn={toggleEditBtn}
                      setChoosenItem={setChoosenItem}
                      setUpdate={setUpdate}
                      darkMode={darkMode}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <h1 className="text-center">No suppliers found</h1>
      )}
    </div>
  );
};

export default SuppliersList;
