import { ICart } from "../../types/models";

const CarDetails = ({ cart }: { cart: ICart }) => {
  return (
    <>
      <h1 className="text-center mt-20">{cart.supplier_name}</h1>
      <div className="text-center my-10">
        <p>Supplier id: {cart.supplier_id}</p>
        <p>Customer id: {cart.customer_id}</p>
      </div>
      <div className="space-y-6">
        <p>Quantity: {cart.cartQuantity}</p>
        <p>Total: {cart.total}</p>
        <p>Paid: {cart.isPaid ? "Paid" : "Not paid"}</p>
        {cart.isPaid && (
          <p>
            Paid at::
            {cart.isPaid ? new Date(cart.paidAt).toLocaleString() : ""}
          </p>
        )}
        <p>
          Delivered:
          {cart.isDelivered ? "Cart is delivered" : "Cart is not delivered"}
        </p>
        {cart.isDelivered && (
          <p>
            Delivered at:
            {cart.isDelivered
              ? new Date(cart.deliveredAt).toLocaleString()
              : ""}
          </p>
        )}
      </div>
    </>
  );
};

export default CarDetails;
