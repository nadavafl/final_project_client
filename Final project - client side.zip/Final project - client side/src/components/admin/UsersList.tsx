import { useState } from "react";
import { IUser } from "../../types/models";
import DeleteUser from "../user/DeleteUser";
import UpdateForm from "../user/UpdateForm";
import UpdateSubscription from "../user/UpdateSubscription";
import UserControlMenu from "./UserControlMenu";
import UserDetails from "./UserDetails";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmark } from "@fortawesome/free-solid-svg-icons";

const UserList = ({
  users,
  refetch,
  darkMode,
}: {
  users: IUser[] | undefined;
  refetch: () => void;
  darkMode: boolean | any;
}) => {
  const [choosenItem, setChoosenItem] = useState<IUser | null>(null);
  const [editBtn, setEditBtn] = useState<any>({});
  const [update, setUpdate] = useState("");
  const toggleEditBtn = (id: string) => {
    setEditBtn((prev: any) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="w-full h-full">
      {choosenItem && (
        <div className="overlay">
          <div
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="fullInfoAdmin bg-slate-300 relative"
          >
            {update === "details" && (
              <UpdateForm
                classStyle={"flex flex-col items-center text-4xl space-y-1"}
                states={true}
                users={choosenItem}
                setChoosenItem={setChoosenItem}
                refetchAdmin={refetch}
                darkMode={darkMode}
              />
            )}
            {update === "subs" && (
              <UpdateSubscription
                users={choosenItem}
                setChoosenItem={setChoosenItem}
                refetchAdmin={refetch}
                darkMode={darkMode}
              />
            )}
            {update === "delete" && (
              <DeleteUser
                users={choosenItem}
                setChoosenItem={setChoosenItem}
                refetchAdmin={refetch}
              />
            )}
            <button
              className="bg-red-500 text-white p-2 rounded-md absolute top-1 right-1 text-2xl hover:bg-red-700 w-1/12"
              onClick={async () => setChoosenItem(null)}
            >
              <FontAwesomeIcon icon={faXmark} />
            </button>
          </div>
        </div>
      )}
      {users?.length ? (
        <div>
          <h1 className="flex justify-center">User`s List</h1>
          <div className="flex flex-wrap items-center justify-center m-10">
            {users?.map((user) => (
              <div
                className="flex flex-wrap items-center justify-center w-full min-h-full sm:w-1/2 md:w-1/3 lg:w-1/2 xl:w-1/3"
                key={user._id}
              >
                <div
                  style={{ backgroundColor: darkMode && "#1f2937" }}
                  id="card"
                  className="flex flex-col text-justify m-3 p-3 text-2xl min-h-full w-full  relative font-bold"
                >
                  <UserDetails user={user} />
                  <UserControlMenu
                    user={user}
                    editBtn={editBtn}
                    toggleEditBtn={toggleEditBtn}
                    setChoosenItem={setChoosenItem}
                    setUpdate={setUpdate}
                    darkMode={darkMode}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <h1 className="text-center">No suppliers found</h1>
      )}
    </div>
  );
};

export default UserList;
