import { Dispatch, SetStateAction } from "react";
import { ICart } from "../../types/models";
import { handleMouseEnter, handleMouseLeave } from "../../helpers/darkModeHover";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faXmark } from "@fortawesome/free-solid-svg-icons";

const CartControlMenu = ({
  cart,
  editBtn,
  toggleEditBtn,
  setChoosenItem,
  setUpdate,
  darkMode,
}: {
  cart: { _id: string };
  editBtn: { [x: string]: boolean };
  toggleEditBtn: (arg0: string) => void;
  setChoosenItem: Dispatch<SetStateAction<ICart | null>>;
  setUpdate: (arg0: string) => void;
  darkMode: boolean | any;
}) => {
  const mouseEnterHandler = handleMouseEnter(darkMode);
  const mouseLeaveHandler = handleMouseLeave(darkMode);

  return (
    <div id="card" className="flex flex-col top-2 absolute left-2 text-xl">
      {!editBtn[cart._id ?? ""] ? (
        <button
          style={{ backgroundColor: darkMode && "#1f2937" }}
          onMouseEnter={mouseEnterHandler}
          onMouseLeave={mouseLeaveHandler}
          className="hover:bg-slate-200 w-full text-left text-3xl"
          onClick={() => toggleEditBtn(cart._id ?? "")}
        >
          <FontAwesomeIcon icon={faPencil} />
        </button>
      ) : (
        <div className="flex flex-col">
          <button
            style={{ backgroundColor: darkMode && "#1f2937" }}
            onMouseEnter={mouseEnterHandler}
            onMouseLeave={mouseLeaveHandler}
            className="hover:bg-slate-200 w-full text-left text-3xl"
            onClick={() => toggleEditBtn(cart._id ?? "")}
          >
            <FontAwesomeIcon icon={faXmark} />
          </button>
          <button
            style={{ backgroundColor: darkMode && "#1f2937" }}
            onMouseEnter={mouseEnterHandler}
            onMouseLeave={mouseLeaveHandler}
            className="hover:bg-slate-200 w-full text-left text-2xl"
            onClick={() => {
              setChoosenItem(cart as ICart);
              setUpdate("delete");
            }}
          >
            Delete
          </button>
        </div>
      )}
    </div>
  );
};

export default CartControlMenu;
