import { ISupplier } from "../../types/models";
import {
  handleMouseEnter,
  handleMouseLeave,
} from "../../helpers/darkModeHover";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faXmark } from "@fortawesome/free-solid-svg-icons";

const SupContolMenu = ({
  supplier,
  editBtn,
  toggleEditBtn,
  setChoosenItem,
  setUpdate,
  darkMode,
}: {
  supplier: ISupplier;
  editBtn: { [key: string]: boolean };
  toggleEditBtn: (id: string) => void;
  setChoosenItem: (item: ISupplier) => void;
  setUpdate: (update: string) => void;
  darkMode: boolean | any;
}) => {
  const mouseEnterHandler = handleMouseEnter(darkMode);
  const mouseLeaveHandler = handleMouseLeave(darkMode);

  return (
    <div id="card" className="flex flex-col absolute top-2 left-2 text-xl">
      {!editBtn[supplier._id ?? ""] ? (
        <button
          style={{ backgroundColor: darkMode && "#1f2937" }}
          onMouseEnter={mouseEnterHandler}
          onMouseLeave={mouseLeaveHandler}
          className="hover:bg-slate-200 w-full text-left text-3xl"
          onClick={() => toggleEditBtn(supplier._id ?? "")}
        >
          <FontAwesomeIcon icon={faPencil} />
        </button>
      ) : (
        <div className="flex flex-col">
          <button
            style={{ backgroundColor: darkMode && "#1f2937" }}
            onMouseEnter={mouseEnterHandler}
            onMouseLeave={mouseLeaveHandler}
            className="hover:bg-slate-200 w-full text-left text-3xl"
            onClick={() => toggleEditBtn(supplier._id ?? "")}
          >
            <FontAwesomeIcon icon={faXmark} />
          </button>
          <button
            style={{ backgroundColor: darkMode && "#1f2937" }}
            onMouseEnter={mouseEnterHandler}
            onMouseLeave={mouseLeaveHandler}
            className="hover:bg-slate-200 w-full text-left text-2xl"
            onClick={() => {
              setChoosenItem(supplier);
              setUpdate("delete");
            }}
          >
            Delete
          </button>
        </div>
      )}
    </div>
  );
};

export default SupContolMenu;
