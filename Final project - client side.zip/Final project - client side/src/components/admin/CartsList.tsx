import { useState } from "react";
import { ICart } from "../../types/models";
import { cartService } from "../../services/cart.service";
import CarDetails from "./CartDetails";
import CartControlMenu from "./CartControlMenu";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmark } from "@fortawesome/free-solid-svg-icons";
import { decodeToken } from "../../utils/jwtDecode";
import { showAlert } from "../../utils/alert";

const CartsList = ({
  carts,
  refetch,
  darkMode,
}: {
  carts: ICart[] | undefined;
  refetch: () => void;
  darkMode: boolean | any;
  }) => {
  const userId = decodeToken()?.id;
  const [choosenItem, setChoosenItem] = useState<ICart | null>(null);
  const [editBtn, setEditBtn] = useState<Record<string, boolean>>({});
  const [update, setUpdate] = useState("");
  const toggleEditBtn = (id: string) => {
    setEditBtn((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div>
      {choosenItem && (
        <div className="overlay">
          <div
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="fullInfoAdmin bg-slate-300 relative"
          >
            {update === "delete" && (
              <div>
                <h1>Are you sure you want to delete this cart?</h1>
                <button
                  className="bg-red-500 text-white p-2 rounded-md w-full mt-8 text-3xl"
                  onClick={async () => {
                    const response = await cartService.deleteCart(
                      userId,
                      choosenItem._id
                    );
                    showAlert("success", response.message, "success");
                    refetch();
                    setChoosenItem(null);
                  }}
                >
                  Yes
                </button>
              </div>
            )}
            <button
              className="bg-red-500 text-white p-2 rounded-md absolute top-1 right-1 text-2xl hover:bg-red-700 w-1/12"
              onClick={async () => setChoosenItem(null)}
            >
              <FontAwesomeIcon icon={faXmark} />
            </button>
          </div>
        </div>
      )}
      {carts?.length ? (
        <div>
          <h1 className="flex justify-center">Carts`s List</h1>
          <div className="flex flex-wrap  justify-center m-10">
            {carts?.map((cart) => (
              <div
                className="flex flex-row items-center justify-center w-full min-h-full sm:w-1/2 md:w-1/3 lg:w-1/2 xl:w-1/3"
                key={cart._id}
              >
                <div
                  style={{ backgroundColor: darkMode && "#1f2937" }}
                  id="card"
                  className="flex flex-col m-3 p-3 text-2xl min-h-full w-full relative font-bold"
                >
                  <CarDetails cart={cart} />
                  <CartControlMenu
                    cart={cart}
                    editBtn={editBtn}
                    toggleEditBtn={toggleEditBtn}
                    setChoosenItem={setChoosenItem}
                    setUpdate={setUpdate}
                    darkMode={darkMode}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <h1 className="text-center">No suppliers found</h1>
      )}
    </div>
  );
};

export default CartsList;
