import { FieldValues, useForm } from "react-hook-form";
import SupplierImage from "./SupplierImage";
import { IProduct, ISupplier } from "../../types/models";
import { MutableRefObject, useEffect, useState } from "react";
import { fieldDisplayNames } from "../../constants/product.constants";
import SupplierProducts from "./SupplierProducts";

const SupplierDetails = ({
  supplier,
  products,
  inStock,
  fileInput,
  uploadImages,
  deleteImages,
  elements,
  deleteItem,
  handleUpdateProduct,
  darkMode,
}: {
  supplier: ISupplier;
  products: IProduct[];
  inStock: (event: any, productId: string) => void;
  fileInput: MutableRefObject<null>;
  uploadImages: (event: any, productId: string) => void;
  deleteImages: (event: any, productId: string, imageId: string) => void;
  elements: string[];
  deleteItem: (event: any, productId: string) => void;
  handleUpdateProduct: (formData: FieldValues) => void;
  darkMode: boolean | any;
}) => {
  const { register, handleSubmit, setValue } = useForm();
  const [editableStates, setEditableStates] = useState({}) as any; 
  const toggleEditState = (productId: string, field: string) => {
    setEditableStates(
      (prevState: { [key: string]: { [key: string]: boolean } }) => ({
        ...prevState,
        [productId]: {
          ...prevState[productId],
          [field]: !prevState[productId]?.[field],
        },
      })
    );
  };

  useEffect(() => {
    Object.entries<Record<string, boolean>>(editableStates).forEach(
      ([productId, fields]) => {
        Object.entries(fields).forEach(([field, editable]) => {
          if (editable) {
            const product = products?.find((p) => p._id === productId) as any;  
            if (product) {
              setValue(`${productId}.${field}`, product[field]);
            }
          }
        });
      }
    );
  }, [editableStates, setValue, products]);

  return (
    <div className="space-y-20  w-full">
      <h1>{supplier.title}</h1>
      <SupplierImage states={false} />
      <SupplierProducts
        products={products}
        inStock={inStock}
        uploadImages={uploadImages}
        deleteImages={deleteImages}
        deleteItem={deleteItem}
        handleUpdateProduct={handleUpdateProduct}
        register={register}
        handleSubmit={handleSubmit}
        elements={elements}
        fieldDisplayNames={fieldDisplayNames}
        fileInput={fileInput}
        editableStates={editableStates}
        setEditableStates={setEditableStates}
        toggleEditState={toggleEditState}
        darkMode={darkMode}
      />
    </div>
  );
};

export default SupplierDetails;
