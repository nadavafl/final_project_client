import { useState, useEffect, SetStateAction, Dispatch } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useParams } from "react-router-dom";
import { ISupplier, ISupplierInput } from "../../types/models";
import { yupSupplierSchema } from "../../validators/supplierRegistrion.yup";
import { useMutation, useQuery } from "react-query";
import { supplierServices } from "../../services/supplier.service";
import { showAlert } from "../../utils/alert";
import FormSupplier from "./FormSupplier";
import FormAddress from "../form/FormAddress";
import FormSupplierOnline from "./FormSupplierOnline";
import Error from "../web/Error";
import Loading from "../web/Loading";

const UpdateSupplier = ({
  setSupplierDetails,
  setUpdateInfo,
  refetch,
  darkMode,
}: {
  setSupplierDetails?: (value: boolean) => void;
  setUpdateInfo?: (value: boolean) => void;
  refetch: () => void;
  darkMode: boolean | any;
}) => {

  const { id } = useParams() as { id: string };
  const { data, isLoading, isError } = useQuery(["supplierUser", id], () =>
    supplierServices.getSupplierById(id)
  );

  const [bizType, setBizType] = useState();
  const [editValues, setEditValues] = useState(false);

  useEffect(() => {
    setBizType(data?.businessType?.type as SetStateAction<undefined>);
  }, [data]);

  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    formState: { errors },
  } = useForm<ISupplierInput>({
    resolver: yupResolver<any>(yupSupplierSchema),
    mode: "onBlur",
  });

  useEffect(() => {
    if (data) {
      for (const key in data) {
        setValue(
          key as keyof ISupplierInput,
          data[key as keyof ISupplierInput]
        );
      }
    }
  }, [data, setValue]);

  const mutation = useMutation(
    (data: ISupplier) => supplierServices.updateSupplierInfo(id, data),
    {
      onSuccess: (data: any) => {
        if (data.message === "Supplier updated") {
          setSupplierDetails && setSupplierDetails(true);
          setUpdateInfo && setUpdateInfo(false);
          showAlert("Success", "Updated successfully", "success");
          refetch();
        }
      },
      onError: (error: any) => {
        showAlert("Error", error.response.data.message, "error");
        showAlert("Error", error.response.data.details[0].message, "error");
      },
    }
  );

  const onSubmit = (data: ISupplierInput) => {
    const sendData = {
      address: data.address,
      description: data.description,
      email: data.email,
      phone: data.phone,
      subtitle: data.subtitle,
      title: data.title,
      web: data.web,
    };
    mutation.mutate(sendData);
  };

  const [chooseBizType, setChooseBizType] = useState(false);

  const [bizTypeInput, setBizTypeInput] = useState([] as string[]);
  useEffect(() => {
    bizType ? setBizTypeInput(bizType) : setBizTypeInput([]);
  }, [bizType]);

  useEffect(() => {
    setValue("businessType", { type: [] } as any);
  }, [setValue]);

  const handleCheckboxChange = (type: string, checked: boolean) => {
    let businessType: any = getValues("businessType") || { type: [] };
    if (checked) {
      if (Array.isArray(businessType.type)) {
        businessType.type.push(type);
      }
      setValue("businessType", businessType);
    }
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div
        className="flex flex-col p-10 items-center justify-center text-3xl font-bold w-full 
   h-full space-y-8 sm:w-1/2 md:w-1/3 lg:w-11/12 xl:w-11/12"
      >
        <h1 className="text-5xl font-bold">Update Supplier</h1>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex pt-8 text-3xl font-bold from-neutral-950 w-full"
        >
          <div
            className={
              "flex flex-col justify-start items-center h-full text-3xl font-bold w-full"
            }
          >
            <div className="flex justify-start h-1/2 text-3xl font-bold w-full">
              <div className="flex flex-col items-end h-full text-3xl font-bold w-1/2 mx-3">
                <div className={chooseBizType ? "overlay" : ""} />
                <FormSupplier
                  register={register}
                  errors={errors}
                  values={data ?? ({} as ISupplierInput)}
                  useDefaultValue={true}
                  isDisabled={!editValues}
                  handleCheckboxChange={handleCheckboxChange}
                  chooseBizType={chooseBizType}
                  bizTypeInput={bizTypeInput}
                  setValue={setValue}
                  darkMode={darkMode}
                />
              </div>
              <div className="flex flex-col items-start h-full text-3xl font-bold w-1/2 mx-3">
                <FormAddress
                  register={register}
                  errors={errors}
                  values={data ?? ({} as ISupplierInput)}
                  useDefaultValue={true}
                  darkMode={darkMode}
                />
              </div>
            </div>
            <div className="flex flex-raw items-center justify-center h-full text-3xl font-bold w-2/3">
              <FormSupplierOnline
                register={register}
                errors={errors}
                values={data ?? ({} as ISupplierInput)}
                useDefaultValue={true}
                darkMode={darkMode}
              />
            </div>
            <div className=" items-center justify-center w-full h-full text-center mt-8">
              <button
                type="submit"
                className="bg-blue-500 hover:bg-blue-400 text-white p-3 w-1/2 rounded-md"
              >
                Submit
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  }
};

export default UpdateSupplier;
