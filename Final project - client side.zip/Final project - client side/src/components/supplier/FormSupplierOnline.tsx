import { useState } from "react";
import { ISupplier, ISupplierInput } from "../../types/models";
import { UseFormRegister, FieldErrors } from "react-hook-form";

const FormSupplierOnline = ({
  register,
  errors,
  values,
  useDefaultValue,
  isDisabled,
  darkMode,
}: {
  register: UseFormRegister<ISupplier>;
  errors: FieldErrors<ISupplierInput>;
  values: ISupplierInput;
  useDefaultValue: boolean;
  isDisabled?: boolean;
  darkMode: boolean | any;
}) => {
  const [web, setWeb] = useState(false);
  return (
    <div className="flex flex-raw justify-start self-center h-full w-full mr- mb-10">
      <label className="flex flex-col mr-3 justify-start h-full w-2/3">
        *Email:
        <input
          {...register("email")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.email}
          defaultValue={useDefaultValue ? values.email : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.email && (
            <p className="text-xl text-red-800">
              {"Email is required. Must be valid email"}
            </p>
          )}
        </div>
      </label>
      <label className="flex flex-col ml-3 justify-start h-full w-2/3">
        *Website:
        <input
          {...register("web")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.web}
          defaultValue={useDefaultValue ? values.web : undefined}
          disabled={isDisabled}
          onKeyDown={() => setWeb(true)}
        />
        {web && (
          <p className="text-xl text-red-800">
            {"Must start with http:// or https://"}
          </p>
        )}
        <div style={{ height: "20px", marginBottom: "10px" }} />
      </label>
    </div>
  );
};

export default FormSupplierOnline;
