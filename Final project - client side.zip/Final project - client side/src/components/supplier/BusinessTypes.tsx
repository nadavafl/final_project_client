import { FieldErrors, UseFormSetValue } from "react-hook-form";
import { IBusinessType, ISupplierInput } from "../../types/models";
import { ChangeEvent } from "react";

const BusinessTypes = ({
  chooseBizType,
  bizTypeInput,
  isDisabled,
  setValue,
  setBizTypeInput,
  setChooseBizType,
  businessTypes,
  handleCheckboxChange,
  errors,
  darkMode,
}: {
  chooseBizType: boolean;
  bizTypeInput: string[];
  isDisabled: boolean;
  setValue: UseFormSetValue<ISupplierInput>;
  setBizTypeInput?: (value: string[]) => void;
  setChooseBizType?: (value: boolean) => void;
  businessTypes: IBusinessType[];
  handleCheckboxChange: (type: string, checked: boolean) => void;
    errors: FieldErrors<ISupplierInput>;
  darkMode: boolean | any;
}) => {
  return (
    <>
      {!chooseBizType && (
        <label className="flex flex-col justify-start h-full w-2/3">
          *Business Type:
          <input
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 mt-5 w-full"
            type="text"
            readOnly
            value={bizTypeInput && bizTypeInput.join(", ")}
            disabled={isDisabled}
            placeholder="Choose business type"
            onClick={() => {
              setValue("businessType", { type: [] } as any);
              setBizTypeInput && setBizTypeInput([]);
              setChooseBizType && setChooseBizType(true);
            }}
          />
          <div style={{ height: "20px", marginBottom: "10px" }} />
        </label>
      )}
      {chooseBizType && (
        <div
          className={
            chooseBizType &&
            "BusinessTypesWindow flex flex-col text-center justify-center p-2 shadow-2xl bg-slate-100 text-3xl font-bold sm:w-1/2 md:w-1/3 lg:w-1/3 xl:w-1/3"
          }
          style={{ backgroundColor: darkMode && "#1f2937" }}
        >
          <label
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="flex flex-col justify-start h-full w-2/3 bg-slate-100"
          >
            Supplier Types:
            {businessTypes.map((type, index) => (
              <div
                className="custom-checkbox flex flex-row justify-start text-left h-full w-full bg-slate-100 mt-4"
                key={index}
              >
                <input
                  type="checkbox"
                  id={`checkbox-${index}`}
                  value={String(type)}
                  disabled={isDisabled}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    handleCheckboxChange(String(type), e.target.checked);
                    setBizTypeInput &&
                      setBizTypeInput([...bizTypeInput, String(type)]);
                  }}
                />
                <label
                  style={{ backgroundColor: darkMode && "#1f2937" }}
                  className="w-full"
                  htmlFor={`checkbox-${index}`}
                >
                  {String(type)}
                </label>
              </div>
            ))}
            <button
              className="bg-blue-400 rounded-lg p-2"
              onClick={() => {
                setChooseBizType && setChooseBizType(false);
              }}
            >
              Done
            </button>
            {errors.businessType && (
              <p className="text-xl text-red-800">
                {"Business Type is required"}
              </p>
            )}
          </label>
        </div>
      )}
    </>
  );
};

export default BusinessTypes;
