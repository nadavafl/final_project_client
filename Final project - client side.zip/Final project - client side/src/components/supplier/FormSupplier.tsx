import { useEffect, useState } from "react";
import { supplierServices } from "../../services/supplier.service";
import { IBusinessType, ISupplier, ISupplierInput } from "../../types/models";
import { UseFormRegister, FieldErrors, UseFormSetValue } from "react-hook-form";
import BusinessTypes from "./BusinessTypes";

const FormSupplier = ({
  register,
  errors,
  values,
  useDefaultValue,
  isDisabled,
  handleCheckboxChange,
  chooseBizType,
  setChooseBizType,
  setValue,
  bizTypeInput,
  setBizTypeInput,
  darkMode,
}: {
  register: UseFormRegister<ISupplier>;
  errors: FieldErrors<ISupplierInput>;
  values: ISupplierInput;
  useDefaultValue: boolean;
  isDisabled: boolean;
  handleCheckboxChange: (type: string, checked: boolean) => void;
  chooseBizType: boolean;
  setChooseBizType?: (value: boolean) => void;
  setValue: UseFormSetValue<ISupplierInput>;
  bizTypeInput: string[];
  setBizTypeInput?: (value: string[]) => void;
  darkMode: boolean | any;
}) => {
  const [businessTypes, setBusinessTypes] = useState<IBusinessType[]>([]);

  useEffect(() => {
    const fetchBusinessTypes = async () => {
      const type = await supplierServices.getBusinessTypes();
      setBusinessTypes(type as IBusinessType[]);
    };

    fetchBusinessTypes();
  }, []);

  return (
    <>
      <BusinessTypes
        chooseBizType={chooseBizType}
        bizTypeInput={bizTypeInput}
        isDisabled={isDisabled}
        setValue={setValue}
        setBizTypeInput={setBizTypeInput}
        setChooseBizType={setChooseBizType}
        businessTypes={businessTypes}
        handleCheckboxChange={handleCheckboxChange}
        errors={errors}
        darkMode={darkMode}
      />
      <label className="flex flex-col justify-start h-full w-2/3">
        *Title:
        <input
          {...register("title")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.title}
          defaultValue={useDefaultValue ? values.title : undefined}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.title && (
            <p className="text-xl text-red-800">{"Title is required"}</p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Subtitle:
        <input
          {...register("subtitle")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.subtitle}
          defaultValue={useDefaultValue ? values.subtitle : undefined}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.subtitle && (
            <p className="text-xl text-red-800">{"Subtitle is required"}</p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Description:
        <textarea
          {...register("description")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-1 mt-5 w-full bg-slate-100 center"
          placeholder={useDefaultValue ? undefined : values.description}
          defaultValue={useDefaultValue ? values.description : undefined}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.description && (
            <p className="text-xl text-red-800">{"Description is required"}</p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Phone:
        <input
          {...register("phone")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.phone}
          defaultValue={useDefaultValue ? values.phone : undefined}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.phone && (
            <p className="text-xl text-red-800">
              {"Phone is required. Must be valid phone number"}
            </p>
          )}
        </div>
      </label>
    </>
  );
};

export default FormSupplier;
