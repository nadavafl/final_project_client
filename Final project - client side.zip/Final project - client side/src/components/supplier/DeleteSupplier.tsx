import { useNavigate, useParams } from "react-router-dom";
import { supplierServices } from "../../services/supplier.service";
import { showAlert } from "../../utils/alert";
import { ISupplier } from "../../types/models";
import { Dispatch, SetStateAction } from "react";

const DeleteSupplier = ({
  refetch,
  suppliers,
  setChoosenItem,
  darkMode,
}: {
  refetch: () => void;
  suppliers?: ISupplier;
  setChoosenItem?: Dispatch<SetStateAction<ISupplier | null>>;
  darkMode: boolean | any;
}) => {
  const { id } = useParams() as { id: string };
  const navigate = useNavigate();
  return (
    <div
      style={{ backgroundColor: darkMode && "#1f2937" }}
      className="flex flex-col items-center text-center space-y-16 lg:w-2/3 mt-4"
    >
      <h1>Are you sure you want to delete the account?</h1>
      <button
        className=" bg-red-500 text-white p-2 rounded-md mt-16 text-3xl font-semibold w-2/3"
        onClick={async () => {
          await supplierServices.deleteSupplier(suppliers?._id ?? id);
          showAlert(
            "Supplier account deleted",
            "Thank you for using our service",
            "success"
          );
          refetch();
          if (suppliers) {
            setChoosenItem && setChoosenItem(null);
            refetch();
          } else {
            navigate("/myBusinesses");
          }
        }}
      >
        Delete
      </button>
    </div>
  );
};

export default DeleteSupplier;
