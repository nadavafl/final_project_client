import { useForm } from "react-hook-form";
import { ISupplierInput } from "../../types/models";
import { useMutation, useQuery } from "react-query";
import { supplierServices } from "../../services/supplier.service";
import { showAlert } from "../../utils/alert";
import { useParams } from "react-router-dom";
import Loading from "../web/Loading";
import Error from "../web/Error";
import { yupDeliveryInfoSchema } from "../../validators/deliveryInfo.yup";
import { yupResolver } from "@hookform/resolvers/yup";

const DeliveryInfo = ({
  setSupplierDetails,
  setDeliveryInfo,
  darkMode,
}: {
  setSupplierDetails: (value: boolean) => void;
  setDeliveryInfo: (value: boolean) => void;
  darkMode: boolean | any;
}) => {
  const { id } = useParams() as { id: string };
  const { data, isLoading, isError, refetch } = useQuery(
    ["supplierUser", id],
    () => supplierServices.getSupplierById(id)
  );
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<ISupplierInput>({
    resolver: yupResolver<any>(yupDeliveryInfoSchema),
    mode: "onBlur",
  });

  const mutation = useMutation(
    (data: any) => supplierServices.updateSupplierInfo(id, data),
    {
      onSuccess: (data: any) => {
        if (data.message === "Supplier updated") {
          showAlert("Success", "Updated successfully", "success");
          refetch();
          setSupplierDetails(true);
          setDeliveryInfo(false);
        }
      },
    }
  );

  const onSubmit = (data: any) => {
    mutation.mutate({ orderDetail: data.orderDetail });
    reset();
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div className="flex flex-col w-full justify-center items-center">
        <h1>Delivery Info</h1>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col pt-8 text-3xl font-bold from-neutral-950 w-2/3  justify-center items-center"
        >
          <label className="flex flex-col justify-start h-full w-2/3">
            *Delivery Days and Area:
            <textarea
              style={{ backgroundColor: darkMode && "#1f2937" }}
              className="p-5 m-5 w-full bg-slate-100"
              defaultValue={
                data.orderDetail?.deliveryAreaDays === undefined
                  ? undefined
                  : data.orderDetail.deliveryAreaDays
              }
              {...register("orderDetail.deliveryAreaDays")}
            />
            {errors.orderDetail?.deliveryAreaDays && (
              <p className="text-xl text-red-800">
                {"Delivery area days must be at least 2 characters"}
              </p>
            )}
          </label>
          <label className="flex flex-col justify-start h-full w-2/3">
            *Minimum Order:
            <input
              style={{ backgroundColor: darkMode && "#1f2937" }}
              className="p-5 m-5 w-full"
              type="number"
              defaultValue={
                data.orderDetail?.minOrder === undefined
                  ? 0
                  : data.orderDetail.minOrder
              }
              {...register("orderDetail.minOrder")}
            />
          </label>
          <label className="flex flex-col justify-start h-full w-2/3">
            *Delivery Fee:
            <input
              style={{ backgroundColor: darkMode && "#1f2937" }}
              className="p-5 m-5 w-full"
              type="number"
              defaultValue={
                data.orderDetail?.deliveryCost === undefined
                  ? 0
                  : data.orderDetail.deliveryCost
              }
              {...register("orderDetail.deliveryCost")}
            />
          </label>
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-400 text-white p-3 w-1/2 rounded-md"
          >
            Submit
          </button>
        </form>
      </div>
    );
  }
};

export default DeliveryInfo;
