import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery } from "react-query";
import Loading from "../web/Loading";
import Error from "../web/Error";
import { supplierServices } from "../../services/supplier.service";
import { useParams } from "react-router-dom";

const SupplierImage = ({
  states,
  setSupplierDetails,
  setUploadImage,
}: {
  states: boolean;
  setSupplierDetails?: (value: boolean) => void;
  setUploadImage?: (value: boolean) => void;
}) => {
  const { id } = useParams() as { id: string };
  const fileInput = useRef(null);
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  const { data, isLoading, isError, refetch } = useQuery(["supplier", id], () =>
    supplierServices.getSupplierById(id)
  );
  const show = states;
  const [imgSrc, setImgSrc] = useState("");

  useEffect(() => {
    if (data) {
      const imageBuffer = (
        data as { image: { file: { data: { data: ArrayBuffer } } } }
      ).image?.file.data.data;
      const blob = new Blob([new Uint8Array(imageBuffer)], {
        type: (data as { image: { file: { contentType: string } } }).image?.file
          .contentType,
      });
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = function () {
        setImgSrc(reader.result as string);
      };
    }
  }, [data]);

  const mutation = useMutation(
    (file: File) => supplierServices.uploadImage(id, token, file),
    {
      onSuccess: () => {
        refetch();
        setSupplierDetails && setSupplierDetails(true);
        setUploadImage && setUploadImage(false);
      },
      onError: (error) => {
        throw error;
      },
    }
  );

  const handleFileChange = (e: any) => {
    const file = e.target.files[0];
    mutation.mutate(file);
  };

  const handleDeleteImage = async () => {
    await supplierServices.deleteImage(id);
    setImgSrc("");
    refetch();
    setSupplierDetails && setSupplierDetails(true);
    setUploadImage && setUploadImage(false);
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div className="space-y-20 w-full">
        {show && <h1>Upload image</h1>}
        <div className="w-full h-full flex justify-center items-center">
          {data.image?.file && (
            <img className="w-1/5 h-1/5 " src={imgSrc} alt="user" />
          )}
        </div>
        {show && (
          <div className="flex flex-col space-y-10 justify-center items-center">
            <button
              className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded-full text-4xl"
              onClick={() => handleDeleteImage()}
            >
              Delete Image
            </button>
            <div className="custom-file-input">
              <input
                type="file"
                ref={fileInput}
                onChange={handleFileChange}
                id="file"
                style={{ display: "none" }}
              />
              <label
                htmlFor="file"
                className="py-2 px-4 bg-blue-500 text-white rounded cursor-pointer hover:bg-blue-600 text-6xl"
              >
                Choose File
              </label>
            </div>
          </div>
        )}
      </div>
    );
  }
};

export default SupplierImage;
