import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { IProduct } from "../../types/models";
import DbImage from "../web/ImageHandler";
import { faPencil, faXmark } from "@fortawesome/free-solid-svg-icons";

const SupplierProducts = ({
  products,
  inStock,
  uploadImages,
  deleteImages,
  deleteItem,
  handleUpdateProduct,
  register,
  handleSubmit,
  elements,
  fieldDisplayNames,
  fileInput,
  editableStates,
  setEditableStates,
  toggleEditState,
  darkMode,
}: {
  products: IProduct[];
  inStock: (event: any, productId: string) => void;
  uploadImages: (event: any, productId: string) => void;
  deleteImages: (event: any, productId: string, imageId: string) => void;
  deleteItem: (event: any, productId: string) => void;
  handleUpdateProduct: (formData: any) => void;
  register: any;
  handleSubmit: any;
  elements: string[];
  fieldDisplayNames: Record<string, string>;
  fileInput: any;
  editableStates: Record<string, Record<string, boolean>>;
  setEditableStates: any;
  toggleEditState: (productId: string, field: string) => void;
  darkMode: boolean | any;
}) => {
  return (
    <div className="flex flex-wrap items-center justify-center m-10 w-full">
      {products?.map((product: any) => (
        <div
          className="flex flex-wrap items-center justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/2 xl:w-1/3"
          key={product._id}
        >
          <div
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="flex flex-col items-center justify-center m-3 p-2 w-3/4 text-3xl relative"
            id="card"
          >
            In stock
            <div className="relative inline-block w-14 align-middle select-none transition duration-200 ease-in">
              <input
                type="checkbox"
                name="toggle"
                id={product._id}
                checked={product.inStock}
                onChange={(event: any) => {
                  inStock(event, product._id);
                }}
                className="bg-slate-600 toggle-checkbox absolute block w-6 h-6 rounded-full border-4 appearance-none cursor-pointer"
              />
              <label
                htmlFor={product._id}
                className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"
              />
            </div>
            {!editableStates[product._id] && (
              <div className="object-cover w-2/4 h-1/4">
                <div
                  onClick={() =>
                    setEditableStates((prevState: Record<string, boolean>) => ({
                      ...prevState,
                      [product._id]: !prevState[product._id],
                    }))
                  }
                  className="w-fit h-fit absolute top-24 left-0 cursor-pointer hover:text-blue-600"
                >
                  <FontAwesomeIcon icon={faPencil} />
                </div>
                <DbImage
                  image={product.images}
                  title={product.title}
                  showBtn={true}
                  style={{
                    maxHeight: "35rem",
                    minHeight: "16.5rem",
                    width: "600px",
                    height: "250px",
                  }}
                />
              </div>
            )}
            {editableStates[product._id] && (
              <div className="object-cover w-2/4 h-1/4">
                <button
                  className="w-fit h-fit absolute top-24 left-0  cursor-pointer hover:text-blue-600"
                  onClick={() =>
                    setEditableStates((prevState: any) => ({
                      ...prevState,
                      [product._id]: !prevState[product._id],
                    }))
                  }
                >
                  <FontAwesomeIcon icon={faXmark} />
                </button>
                <div className="custom-file-input">
                  <input
                    type="file"
                    ref={fileInput}
                    id="file"
                    style={{ display: "none" }}
                    onChange={(event: any) => uploadImages(event, product._id)}
                  />
                  <label
                    htmlFor="file"
                    className="w-fit h-fit absolute top-32 left-0  cursor-pointer hover:text-blue-600"
                  >
                    Upload
                  </label>
                </div>
                <DbImage
                  image={product.images}
                  title={product.title}
                  showBtn={true}
                  style={{
                    maxHeight: "35rem",
                    minHeight: "16.5rem",
                    width: "600px",
                    height: "250px",
                  }}
                  deleteImages={deleteImages}
                  productId={product._id}
                />
              </div>
            )}
            <form
              className="flex flex-col w-full p-5"
              onSubmit={handleSubmit(handleUpdateProduct)}
            >
              {elements.map((element: any) => (
                <div className="flex w-full justify-between p-5" key={element}>
                  <label htmlFor={element}>
                    {fieldDisplayNames[
                      element as keyof typeof fieldDisplayNames
                    ] || element}
                  </label>
                  {editableStates[product._id]?.[element] ? (
                    <input
                      style={{ backgroundColor: darkMode && "#1f2937" }}
                      className="w-1/2 p-2 border-2 rounded-md"
                      type="text"
                      {...register(`${product._id}.${element}`)}
                    />
                  ) : (
                    <p>{product[element]}</p>
                  )}
                  <button
                    type="button"
                    className="hover:text-blue-600"
                    onClick={() => toggleEditState(product._id, element)}
                  >
                    {editableStates[product._id]?.[element] ? (
                      <FontAwesomeIcon icon={faXmark} />
                    ) : (
                      <FontAwesomeIcon icon={faPencil} />
                    )}
                  </button>
                </div>
              ))}
              <button
                className="bg-blue-500 hover:bg-blue-400 text-white font-semibold p-3 w-full rounded-md"
                type="submit"
                onClick={() => setEditableStates(!editableStates[product._id])}
              >
                Submit
              </button>
            </form>
            <button
              onClick={(event: any) => deleteItem(event, product._id)}
              className="bg-red-500 hover:bg-red-400 text-white font-semibold p-3 w-11/12 rounded-md"
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SupplierProducts;
