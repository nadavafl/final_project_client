import { useForm } from "react-hook-form";
import { IProductInput } from "../../types/models";
import { useMutation } from "react-query";
import { productService } from "../../services/product.service";
import { useParams } from "react-router-dom";
import { showAlert } from "../../utils/alert";
import { yupResolver } from "@hookform/resolvers/yup";
import { yupProductSchema } from "../../validators/product.yup";

const AddProduct = ({
  setSupplierDetails,
  setAddProduct,
  refetch,
  darkMode,
}: {
  setSupplierDetails: (value: boolean) => void;
  setAddProduct: (value: boolean) => void;
  refetch: () => void;
  darkMode: boolean | any;
}) => {
  const { id } = useParams() as { id: string };
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IProductInput>({
    resolver: yupResolver<any>(yupProductSchema),
    mode: "onBlur",
  });

  const mutation = useMutation(
    (data: any) => productService.addProduct(id, data),
    {
      onSuccess: (data: any) => {
        if (data.message === "Product created") {
          showAlert("Success", data.message, "success");
          refetch();
          setSupplierDetails(true);
          setAddProduct(false);
        }
      },
    }
  );

  const onSubmit = (data: any) => {
    data.inStock = data.inStock === "In Stock" ? true : false;
    mutation.mutate(data);
  };

  return (
    <div className="flex flex-col w-full justify-center items-center">
      <h1>Add Product</h1>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col pt-8 text-3xl font-bold from-neutral-950 w-2/3  justify-center items-center mt-20"
      >
        <label className="flex flex-col justify-start h-full w-2/3">
          *Product id:
          <input
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 m-5 w-full "
            type="text"
            {...register("product_number", { required: true })}
          />
          <div style={{ height: "20px", marginBottom: "2px" }}>
            {errors.product_number && (
              <p className="text-xl text-red-800 text-left">
                {"Product number is required"}
              </p>
            )}
          </div>
        </label>
        <label className="flex flex-col justify-start h-full w-2/3">
          *Title:
          <input
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 m-5 w-full"
            type="text"
            {...register("title", { required: true })}
          />
          <div style={{ height: "20px", marginBottom: "2px" }}>
            {errors.title && (
              <p className="text-xl text-red-800 text-left">
                {"Title is required"}
              </p>
            )}
          </div>
        </label>
        <label className="flex flex-col justify-start h-full w-2/3">
          *Description:
          <textarea
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 m-5 w-full bg-slate-100"
            {...register("description", { required: true })}
          />
          <div style={{ height: "20px", marginBottom: "2px" }}>
            {errors.description && (
              <p className="text-xl text-red-800 text-left">
                {"Description is required"}
              </p>
            )}
          </div>
        </label>
        <label className="flex flex-col justify-start h-full w-2/3">
          Stock:
          <input
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 m-5 w-full"
            type="number"
            {...register("stock")}
          />
          <div style={{ height: "20px", marginBottom: "2px" }} />
        </label>
        <label className="flex flex-col justify-start h-full w-2/3">
          *In stock:
          <select
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 m-5 w-full bg-slate-100"
            {...register("inStock", { required: true })}
          >
            <option value="In Stock">In Stock</option>
            <option value="Out of Stock">Out of Stock</option>
          </select>
          <div style={{ height: "20px", marginBottom: "2px" }}>
            {errors.inStock && (
              <p className="text-xl text-red-800 text-left">
                {"In stock is required"}
              </p>
            )}
          </div>
        </label>
        <label className="flex flex-col justify-start h-full w-2/3">
          *Price:
          <input
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 m-5 w-full"
            type="number"
            {...register("price", { required: true })}
          />
          <div style={{ height: "20px", marginBottom: "2px" }}>
            {errors.price && (
              <p className="text-xl text-red-800 text-left">
                {"Price is required"}
              </p>
            )}
          </div>
        </label>
        <button
          className="bg-blue-500 hover:bg-blue-400 text-white p-3 w-1/2 rounded-md mt-9"
          type="submit"
        >
          Add Product
        </button>
      </form>
    </div>
  );
};

export default AddProduct;
