import { useNavigate } from "react-router-dom";
import { userServices } from "../../services/user.service";
import { showAlert } from "../../utils/alert";
import { useUser } from "../../hooks/useUser";
import { IUser } from "../../types/models";
import { decodeToken } from "../../utils/jwtDecode";
import { Dispatch, SetStateAction } from "react";

const DeleteUser = ({
  users,
  setChoosenItem,
  refetchAdmin,
}: {
  users?: IUser;
  setChoosenItem?: Dispatch<SetStateAction<IUser | null>>;
  refetchAdmin?: () => void;
}) => {
  const navigate = useNavigate();
  const { setUser } = useUser();
  const id = decodeToken()?.id ?? "";
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";

  return (
    <div className="flex flex-col justify-center space-y-16">
      <h1>Are you sure you want to delete the account?</h1>
      <button
        className="bg-red-500 text-white p-2 rounded-md mt-16 text-3xl"
        onClick={async () => {
          await userServices.deleteUser(users?._id ?? id);

          showAlert(
            "Account deleted",
            "Thank you for using our service",
            "success"
          );
          if (!users) {
            navigate("/");
            setUser("guest");
            sessionStorage.removeItem("token");
          }
          if (users) {
            setChoosenItem && setChoosenItem(null);
            refetchAdmin && refetchAdmin();
          }
        }}
      >
        Delete
      </button>
    </div>
  );
};

export default DeleteUser;
