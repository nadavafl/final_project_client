import { IUserInput } from "../../types/models";
import { UseFormRegister, FieldErrors } from "react-hook-form";

const FormUser = ({
  register,
  errors,
  values,
  useDefaultValue,
  isDisabled,
  darkMode,
}: {
  register: UseFormRegister<IUserInput>;
  errors: FieldErrors<IUserInput>;
  values: IUserInput;
  useDefaultValue: boolean;
  isDisabled: boolean;
  darkMode: boolean | any;
}) => {
  return (
    <>
      <label className="flex flex-col justify-start h-full w-2/3">
        *First name:
        <input
          {...register("name.first")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.name.first}
          defaultValue={useDefaultValue ? values.name.first : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.name?.first && (
            <p className="text-xl text-red-800">{"First name is required"}</p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        Middle name:
        <input
          {...register("name.middle")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.name.middle}
          defaultValue={useDefaultValue ? values.name.middle : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }} />
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Last name:
        <input
          {...register("name.last")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.name.last}
          defaultValue={useDefaultValue ? values.name.last : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.name?.last && (
            <p className="text-xl text-red-800">{"Last name is required"}</p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Phone:
        <input
          {...register("phone")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full "
          type="text"
          placeholder={useDefaultValue ? undefined : values.phone}
          defaultValue={useDefaultValue ? values.phone : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.phone && (
            <p className="text-xl text-red-800">
              {"Phone is required. Must be valid phone number"}
            </p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Email:
        <input
          {...register("email")}
      style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : values.email}
          defaultValue={useDefaultValue ? values.email : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "2px" }}>
          {errors.email && (
            <p className="text-xl text-red-800">
              {"Email is required. Must be valid email"}
            </p>
          )}
        </div>
      </label>
    </>
  );
};

export default FormUser;
