import { useEffect, useRef, useState } from "react";
import { decodeToken } from "../../utils/jwtDecode";
import { useMutation, useQuery } from "react-query";
import { userServices } from "../../services/user.service";
import Loading from "../web/Loading";
import Error from "../web/Error";
import { useContext } from "react";
import { ImageContext } from "../../contexts/ImageContext";

const UploadImage = ({ states }: { states: boolean }) => {
  const id = decodeToken()?.id ?? "";
  const fileInput = useRef(null);
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";
  const { setUserImg } = useContext(ImageContext);
  const { data, isLoading, isError, refetch } = useQuery(["user", id], () =>
    userServices.getUser(id)
  );
  const show = states;
  const [imgSrc, setImgSrc] = useState("");

  useEffect(() => {
    if (data) {
      const imageBuffer = data.image?.file.data.data;
      const blob = new Blob([new Uint8Array(imageBuffer)], {
        type: data.image?.file.contentType,
      });
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = function () {
        setImgSrc(reader.result as string);
        setUserImg(reader.result as string);
      };
    }
  }, [data]);

  const mutation = useMutation(
    (file: File) => userServices.uploadImage(id, file),
    {
      onSuccess: () => {
        refetch();
      },
      onError: (error) => {
        throw error;
      },
    }
  );

  const handleFileChange = (e: any) => {
    const file = e.target.files[0];
    mutation.mutate(file);
  };

  const handleDeleteImage = async () => {
    await userServices.deleteImage(id);
    setUserImg("");
    refetch();
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div className="space-y-20 w-full">
        {show && <h1>Upload image</h1>}
        <div className="w-full h-full flex justify-center items-center">
          {data.image?.file && (
            <img className="w-1/4 h-1/4 " src={imgSrc} alt="user" />
          )}
        </div>
        {show && (
          <div className="flex flex-col space-y-10 justify-center items-center">
            <button
              className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded-full text-3xl"
              onClick={() => handleDeleteImage()}
            >
              Delete Image
            </button>
            <div className="custom-file-input">
              <input
                type="file"
                ref={fileInput}
                onChange={handleFileChange}
                id="file"
                style={{ display: "none" }}
              />
              <label
                htmlFor="file"
                className="py-2 px-4 bg-blue-500 text-white rounded cursor-pointer hover:bg-blue-600"
              >
                Choose File
              </label>
            </div>
          </div>
        )}
      </div>
    );
  }
};

export default UploadImage;
