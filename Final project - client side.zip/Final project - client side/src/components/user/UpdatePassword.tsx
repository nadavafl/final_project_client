import { useForm } from "react-hook-form";
import { IUserInput } from "../../types/models";
import Error from "../web/Error";
import Loading from "../web/Loading";
import { yupResolver } from "@hookform/resolvers/yup";
import { showAlert } from "../../utils/alert";
import { useMutation, useQuery } from "react-query";
import { userServices } from "../../services/user.service";
import { useParams } from "react-router-dom";
import Password from "./Password";
import { yupPasswordSchema } from "../../validators/userPassword.yup";

const UpdatePassword = ({darkMode}: {darkMode: boolean|any}) => {
  const { id } = useParams() as { id: string };
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";

  const { data, isLoading, isError, refetch } = useQuery(["user", id], () =>
    userServices.getUser(id)
  );

  const mutation = useMutation(
    (newData: IUserInput) => userServices.updateUser(id, newData),
    {
      onSuccess: () => {
        refetch();
        showAlert("success", "User updated successfully", "success");
      },
      onError: (error: any) => {
        throw error;
      },
    }
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IUserInput>({
    resolver: yupResolver<any>(yupPasswordSchema),
    mode: "onBlur",
  });

  const onSubmit = (newData: IUserInput) => {
    mutation.mutate(newData);
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div
        className="flex flex-col p-10 items-center justify-center text-3xl font-bold w-full 
     h-full"
      >
        <h1>Update Password</h1>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="pt-8 text-3xl font-bold from-neutral-950 w-full my-20"
        >
          <div className="flex justify-center">
            <Password register={register} errors={errors} values={""} darkMode={darkMode} />
          </div>
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-400 text-white p-3 w-1/2 rounded-md mt-10"
          >
            Submit
          </button>
        </form>
      </div>
    );
  }
};

export default UpdatePassword;
