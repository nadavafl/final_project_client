import { IUserInput } from "../../types/models";
import { FieldErrors, UseFormSetValue, UseFormWatch } from "react-hook-form";
import { useUser } from "../../hooks/useUser";

const FormRole = ({
  errors,
  setValue,
  watch,
  darkMode,
}: {
  errors: FieldErrors;
  setValue: UseFormSetValue<IUserInput>;
  watch: UseFormWatch<IUserInput>;
  darkMode: boolean | any;
}) => {
  const { user } = useUser();
  return (
    <label className="flex flex-col self-end items-center h-full w-full my-10">
      *Subscription:
      <div className="flex justify-center my-10">
        <div
          style={{ backgroundColor: darkMode && "#1f2937" }}
          onClick={() => {
            setValue("role.name", "Subscriber");
          }}
          className={`block p-5 m-4 text-center w-1/2 h-auto border-2 cursor-pointer relative ${
            watch("role.name") === "Subscriber" ||
            (!watch("role.name") && user === "Subscriber")
              ? !darkMode
                ? "border-blue-900 bg-yellow-300"
                : "border-white border-8"
              : !darkMode
              ? "border-gray-500 bg-white"
              : "border-gray-500 border-4"
          }`}
        >
          <h1 className="my-3">Subscriber</h1>
          <div className="text-left space-x-10">
            <p>Our business users get to:</p>
            <p>1. view and edit their own profile</p>
            <p>2. save their favorite suppliers and products</p>
            <p>3. rate suppliers and products</p>
            <p>4. advertise in METROLINE</p>
          </div>
          <div className="pt-14">Cost: Free of charge</div>
        </div>
        <div
          style={{ backgroundColor: darkMode && "#1f2937" }}
          onClick={() => {
            setValue("role.name", "BusinessUser");
          }}
          className={`block p-5 m-4 text-center w-1/2 h-auto border-2 cursor-pointer relative${
            watch("role.name") === "BusinessUser" ||
            (!watch("role.name") && user === "BusinessUser")
              ? !darkMode
                ? "border-blue-900 bg-yellow-300"
                : "border-white border-8"
              : !darkMode
              ? "border-gray-500 bg-white"
              : "border-gray-500 border-4"
          }`}
        >
          <h1 className="my-3">Business</h1>
          <div className="text-left space-x-10">
            <p>Our business users get to:</p>
            <p>1. view and edit their own profile</p>
            <p>2. save their favorite suppliers and products</p>
            <p>3. rate suppliers and products</p>
            <p>4. advertise in METROLINE</p>
            <p>5. create and manage their own suppliers</p>
          </div>
          <div className="pt-6">Cost: 100$ per year</div>
        </div>
      </div>
      {errors.role && (
        <p className="text-xl text-red-800 w-2/3 text-center">
          Please select a subscription
        </p>
      )}
    </label>
  );
};

export default FormRole;
