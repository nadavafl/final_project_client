import { useForm } from "react-hook-form";
import FormRole from "./Role";
import { IUser, IUserInput } from "../../types/models";
import { yupResolver } from "@hookform/resolvers/yup";
import { yupUpdateRoleSchema } from "../../validators/updateUserRole.yup";
import { useParams } from "react-router-dom";
import { useMutation, useQuery } from "react-query";
import { userServices } from "../../services/user.service";
import { showAlert } from "../../utils/alert";
import Loading from "../web/Loading";
import Error from "../web/Error";
import { Dispatch, SetStateAction } from "react";

const UpdateSubscription = ({
  users,
  setChoosenItem,
  refetchAdmin,
  darkMode,
}: {
  users?: IUser;
  setChoosenItem?: Dispatch<SetStateAction<IUser | null>>;
  refetchAdmin?: () => void;
  darkMode: boolean | any;
}) => {
  const { id } = useParams() as { id: string };
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";

  const { data, isLoading, isError, refetch } = useQuery(["user", id], () =>
    userServices.getUser(id)
  );

  const mutation = useMutation(
    (newData: IUserInput) => userServices.changeRole(users?._id ?? id, newData),
    {
      onSuccess: () => {
        refetch();
        showAlert("success", "User updated successfully", "success");
        if (users) {
          setChoosenItem && setChoosenItem(null);
          refetchAdmin && refetchAdmin();
        }
      },
      onError: (error) => {
        throw error;
      },
    }
  );

  const {
    setValue,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<IUserInput>({
    resolver: yupResolver<any>(yupUpdateRoleSchema),
    mode: "onBlur",
  });

  const onSubmit = (newData: IUserInput) => {
    mutation.mutate(newData);
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (users ?? data) {
    return (
      <div
        className="flex flex-col p-10 items-center justify-center text-3xl font-bold w-full 
     h-full"
      >
        <h1>Update Subscription</h1>
        {users && (
          <p className="mt-8">
            {users.name.first} subscribe as <u>{users.role?.name}</u>{" "}
          </p>
        )}
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col items-center pt-8 text-3xl font-bold from-neutral-950 w-full"
        >
          <FormRole errors={errors} setValue={setValue} watch={watch} darkMode={darkMode} />
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-400 text-white p-3 w-1/2 rounded-md mt-10"
          >
            Submit
          </button>
        </form>
      </div>
    );
  }
};

export default UpdateSubscription;
