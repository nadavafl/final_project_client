import { useQuery, useMutation } from "react-query";
import { useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { userServices } from "../../services/user.service";
import Loading from "../web/Loading";
import Error from "../web/Error";
import { IUser, IUserInput } from "../../types/models";
import FormUser from "./FormUser";
import FormAddress from "../form/FormAddress";
import { yupResolver } from "@hookform/resolvers/yup";
import { yupUserUpdateSchema } from "../../validators/userUpdate.yup";
import { showAlert } from "../../utils/alert";
import { Dispatch, SetStateAction } from "react";

const UpdateForm = ({
  states,
  users,
  classStyle,
  setChoosenItem,
  refetchAdmin,
  darkMode,
}: {
  states: boolean;
  users?: IUser;
  classStyle?: string;
  setChoosenItem?: Dispatch<SetStateAction<IUser | null>>;
  refetchAdmin?: () => void;
  darkMode?: boolean | any;
}) => {
  let { id } = useParams() as { id: string | undefined };
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "guest";

  const { data, isLoading, isError, refetch } = useQuery(["user", id], () =>
    userServices.getUser(id)
  );
  const show = states;
  const mutation = useMutation(
    (newData: IUserInput) => userServices.updateUser(users?._id ?? id, newData),
    {
      onSuccess: () => {
        refetch();
        showAlert("success", "User updated successfully", "success");
        if (users) {
          setChoosenItem && setChoosenItem(null);
          refetchAdmin && refetchAdmin();
        }
      },
      onError: (error) => {
        throw error;
      },
    }
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IUserInput>({
    resolver: yupResolver<any>(yupUserUpdateSchema),
    mode: "onBlur",
  });

  const onSubmit = (newData: IUserInput) => {
    mutation.mutate(newData);
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (users ?? data) {
    return (
      <div
        style={{ backgroundColor: darkMode && "#1f2937" }}
        className="flex flex-col items-center justify-center text-3xl font-bold w-full 
     h-full"
      >
        {show && <h1 className="mb-10">Update my Details</h1>}
        <form
          onSubmit={handleSubmit(onSubmit)}
          className={classStyle ?? "pt-8 text-3xl font-bold w-full"}
        >
          <div className="flex flex-col justify-start h-full text-3xl font-bold w-full">
            <div className="flex justify-start h-1/2 text-3xl font-bold w-full">
              <div className="flex flex-col items-end h-full text-3xl font-bold w-1/2 p-3">
                <FormUser
                  register={register}
                  errors={errors}
                  values={users ?? data ?? ({} as IUserInput)}
                  useDefaultValue={true}
                  isDisabled={!show}
                  darkMode={darkMode}
                />
              </div>
              <div className="flex flex-col items-start h-full text-3xl font-bold w-1/2 p-3">
                <FormAddress
                  register={register}
                  errors={errors}
                  values={users ?? data ?? ({} as IUserInput)}
                  useDefaultValue={true}
                  isDisabled={!show}
                  darkMode={darkMode}
                />
              </div>
            </div>
          </div>
          {show && (
            <button
              type="submit"
              className="bg-blue-500 hover:bg-blue-400 text-white p-3 w-1/2 rounded-md mt-10"
            >
              Submit
            </button>
          )}
        </form>
      </div>
    );
  }
};

export default UpdateForm;
