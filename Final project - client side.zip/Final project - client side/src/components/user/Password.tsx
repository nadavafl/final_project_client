import { useState } from "react";
import { IUserInput } from "../../types/models";
import { UseFormRegister, FieldErrors } from "react-hook-form";

const Password = ({
  register,
  errors,
  values,
  darkMode,
}: {
  register: UseFormRegister<IUserInput>;
  errors: FieldErrors<IUserInput>;
  values: any;
  darkMode: boolean | any;
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [showRepeatPassword, setShowRepeatPassword] = useState(false);
  return (
    <div className="flex flex-raw justify-start self-center h-full w-2/3 mr-10 mb-10">
      <label className="flex flex-col mr-6 justify-start h-full w-2/3 relative">
        <p className="ml-5">*Password:</p>
        <input
          {...register("password")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 m-5 w-full "
          type={showPassword ? "text" : "password"}
          placeholder={values.regPassword ? values.regPassword : "Password"}
        />
        <button 
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-5 top-20"
        >
          {showPassword ? "Hide" : "Show"}
        </button>
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.password && (
            <p className="text-xl text-red-800 w-2/3">
              {
                "Password is required. Must be 7-20 characters, contain at least: one uppercase and one lowercase letter, one number and one special character"
              }
            </p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3 relative">
        <p className="ml-5">*Repeat Password:</p>
        <input
          {...register("repeatPassword")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 m-5 w-full"
          type={showRepeatPassword ? "text" : "password"}
          placeholder="Repeat Password"
        />
        <button 
          type="button"
          onClick={() => setShowRepeatPassword(!showRepeatPassword)}
          className="absolute right-5 top-20"
        >
          {showRepeatPassword ? "Hide" : "Show"}
        </button>
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.repeatPassword && (
            <p className="text-xl text-red-800 w-2/3">
              {"Passwords must match"}
            </p>
          )}
        </div>
      </label>
    </div>
  );
};

export default Password;
