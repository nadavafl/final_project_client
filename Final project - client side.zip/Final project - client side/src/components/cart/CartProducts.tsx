import { ICartItem } from "../../types/models";

const CartProducts = ({
  product,
  darkMode,
}: {
  product: ICartItem;
  darkMode: boolean | any;
}) => {
  return (
    <div
      key={product._id}
      style={{
        backgroundColor: darkMode && "#1f2937",
        border: darkMode && "2px solid #F1F5F9",
      }}
      className="flex flex-col m-10 p-10 bg-white text-left"
    >
      <p>Title: {product.title}</p>
      <p className="p-1">Price: {product.price}</p>
      <div className="flex flex-row">
        <p>Quant: {product.quantity}</p>
      </div>
    </div>
  );
};

export default CartProducts;
