import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { ICartItem } from "../../types/models";
import { faMinus, faPlus, faTrash } from "@fortawesome/free-solid-svg-icons";

interface CartProductProps {
  product: ICartItem;
  onRemoveItem?: (productId: string) => void;
  onAddReduce?: (productId: string, quantity: number) => void;
  disableQuantity?: boolean;
}
const ProductFunctions = ({
  product,
  onRemoveItem,
  onAddReduce,
  disableQuantity,
}: CartProductProps) => {
  return (
    <div className="flex p-1 text-left space-y-3 text-2xl">
      <div className="flex flex-col">
        <p className="absolute top-0 left-6">{product.title}</p>
        <p>{product.price}$</p>
        <p className="absolute bottom-0 left-6 flex">
          Quantity{disableQuantity &&<p className="ml-5"> {product.quantity}</p>}
        </p>
      </div>
      {onRemoveItem && (
        <div>
          <div className="flex flex-row justify-center absolute bottom-0 right-0 space-x-3">
            <button onClick={() => onAddReduce && onAddReduce(product._id, +1)}>
              <FontAwesomeIcon icon={faPlus} />
            </button>
            <p>{product.quantity}</p>
            <button onClick={() => onAddReduce && onAddReduce(product._id, -1)}>
              <FontAwesomeIcon icon={faMinus} />
            </button>
          </div>
          <button
            onClick={() => onRemoveItem && onRemoveItem(product._id)}
            className=" hover:bg-red-500 absolute top-0 right-0"
          >
            <FontAwesomeIcon icon={faTrash} />
          </button>
        </div>
      )}
    </div>
  );
};

export default ProductFunctions;
