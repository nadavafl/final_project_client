import { useQuery } from "react-query";
import Error from "../web/Error";
import Loading from "../web/Loading";
import { cartService } from "../../services/cart.service";
import { useParams } from "react-router-dom";
import Cart from "./Cart";
import { ICart } from "../../types/models";
import { useDeleteCart } from "../../hooks/useDeleteCart";
import { decodeToken } from "../../utils/jwtDecode";
import { showAlert } from "../../utils/alert";

const Carts = ({ darkMode }: { darkMode: boolean | any }) => {
  const userId = decodeToken()?.id;
  const { id } = useParams() as { id: string };
  let token = sessionStorage.getItem("token");
  token = token ? JSON.parse(token) : "";
  const { data, isLoading, isError, refetch } = useQuery("supplierCarts", () =>
    cartService.getAllCartsBySupplier(id)
  );
  const deleteCart = useDeleteCart(token, refetch);
  const approveDelivery = async (cartId: string, customerId: string) => {
    const response = await cartService.approveDelivery(id, cartId, customerId);
    showAlert("success", response.message, "success");
    refetch();
  };

  if (isLoading) return <Loading />;
  if (isError) return <Error />;
  if (data) {
    return (
      <div className="flex flex-col text-center content-center text-3xl tracking-wides font-bold">
        <h1>Carts</h1>
        <div className="flex flex-wrap items-center justify-center mt-10">
          {data.carts.map((cart: ICart) => (
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              id="card"
              className="flex flex-col items-center justify-center m-3 p-2"
              key={cart._id}
            >
              <p>Customer id: {cart.customer_id}</p>
              <Cart
                cart={cart}
                approveDelivery={approveDelivery}
                onDelete={() =>
                  deleteCart.mutate({
                    cartId: cart._id,
                    userId: userId || "",
                  })
                }
                darkMode={darkMode}
                disableQuantity={true}
              />
              <p>
                Delivery status:{" "}
                {cart.isDelivered ? "Delivered" : "Not delivered"}
              </p>
            </div>
          ))}
        </div>
      </div>
    );
  }
};

export default Carts;
