import { ICart } from "../../types/models";
import ProductFunctions from "./ProductFunctions";

interface cartProps {
  cart: ICart;
  onDelete?: () => void;
  onRemoveItem?: (productId: string) => void;
  onAddReduce?: (productId: string, quantity: number) => void;
  onPayment?: () => void;
  approveDelivery?: (cartId: string, customerId: string) => Promise<void>;
  darkMode?: boolean | any;
  disableQuantity?: boolean;
}

const Cart = ({
  cart,
  onDelete,
  onRemoveItem,
  onAddReduce,
  onPayment,
  approveDelivery,
  darkMode,
  disableQuantity,
}: cartProps) => {
  return (
    <div
      className="block items-center justify-center p-2 bg-transparent space-y-8 m-5 min-h-96"
      key={cart._id}
    >
      <p>{cart.supplier_name}</p>
      {cart.items.map((product) => (
        <div
          style={{
            backgroundColor: darkMode && "#1f2937",
            border: darkMode && "2px solid #F1F5F9",
          }}
          className="flex flex-col p-5 m-3 bg-white relative w-fit-content rounded-lg shadow-lg"
          key={product._id}
        >
          <ProductFunctions
            product={product}
            onRemoveItem={onRemoveItem}
            onAddReduce={onAddReduce}
            disableQuantity={disableQuantity}
          />
        </div>
      ))}
      {!cart.isPaid ? (
        <p>Total: {cart.total}$</p>
      ) : (
        cart.invoice && (
            <div className="flex flex-col p-5 m-3 bg-white relative w-fit-content rounded-lg shadow-lg">
            <p>Paid Invoice</p>
            <p className="mt-20">Quantity: {cart.invoice.items.length}</p>
            <p className="mt-20">Total: {cart.invoice.total}$</p>
          </div>
        )
      )}
        <button
          onClick={onDelete}
          className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded-l-full mx-2"
        >
          Delete cart
        </button>
      {onPayment && (
        <>
          <button
            onClick={onPayment}
            className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-r-full"
          >
            Payment
          </button>
        </>
      )}
      {approveDelivery && (
        <>
          {!cart.isDelivered && (
            <button
              onClick={() => approveDelivery(cart._id, cart.customer_id)}
              className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-r-full"
            >
              approve delivery
            </button>
          )}
        </>
      )}
    </div>
  );
};

export default Cart;
