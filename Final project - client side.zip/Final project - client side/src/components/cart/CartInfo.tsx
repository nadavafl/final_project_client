import { ICart } from "../../types/models";
import CartProducts from "./CartProducts";

const CartCard = ({
  cart,
  onDelete,
  darkMode,
}: {
  cart: ICart;
  onDelete: () => void;
  darkMode: boolean | any;
}) => {
  return (
    <div
      style={{ backgroundColor: darkMode && "#1f2937" }}
      id="card"
      className="block m-3 p-2 w-1/4"
    >
      <p>Supplier: {cart.supplier_name}</p>

      {cart.invoice.items.map((product) => (
        <CartProducts product={product} darkMode={darkMode} key={product._id} />
      ))}
      <p className="mb-6">Total: {cart.invoice.total}</p>
      <button
        onClick={onDelete}
        className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded-full"
      >
        Delete cart
      </button>
    </div>
  );
};

export default CartCard;
