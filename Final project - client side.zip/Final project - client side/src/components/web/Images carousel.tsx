import homePage1 from "../../assets/homePage1.jpg";
import homePage2 from "../../assets/homePage2.jpg";
import homePage3 from "../../assets/homePage3.jpg";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

const ImagesCarousel = () => {
  return (
    <Carousel
      autoPlay
      infiniteLoop
      showThumbs={false}
      showArrows={false}
      showStatus={false}
    >
      <div>
        <img
          style={{
            maxHeight: "35rem",
            minHeight: "16.5rem",
            width: "1550px",
            height: "900px",
          }}
          className="rounded-lg"
          src={homePage1}
          alt="First slide"
        />
      </div>
      <div>
        <img
          style={{
            maxHeight: "35rem",
            minHeight: "16.5rem",
            width: "1550px",
            height: "900px",
          }}
          className="rounded-lg"
          src={homePage2}
          alt="Second slide"
        />
      </div>
      <div>
        <img
          style={{
            maxHeight: "35rem",
            minHeight: "16.5rem",
            width: "1550px",
            height: "900px",
          }}
          className="rounded-lg"
          src={homePage3}
          alt="Third slide"
        />
      </div>
    </Carousel>
  );
};

export default ImagesCarousel;