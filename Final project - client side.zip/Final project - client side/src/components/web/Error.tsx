import errorImg from "../../assets/404.jpg";

const Error = () => (
    <div
        style={{ backgroundColor: "#333041" }}
        className="min-h-screen">
      <h1 className="text-6xl text-white text-center mb-10">
        Something went wrong...
      </h1>
      <img
        className="w-1/2 h-1/3 mx-auto"
        src={errorImg}
        alt="Something went wrong..."
      />
    </div>
);

export default Error;