import { faLeftLong, faRightLong } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Buffer } from "buffer";
import { CSSProperties, useState } from "react";

const DbImage = ({
  image,
  title,
  showBtn,
  style,
  deleteImages,
  productId,
}: {
  image: any;
  title: string;
  showBtn?: boolean;
  style?: CSSProperties | undefined;
  deleteImages?: (event: any, productId: string, imageId: string) => void;
  productId?: string;
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const handleNextImage = () => {
    setCurrentImageIndex((prevIndex: number) => (prevIndex + 1) % image.length);
  };

  const handlePrevImage = () => {
    setCurrentImageIndex((prevIndex: number) =>
      prevIndex === 0 ? image.length - 1 : prevIndex - 1
    );
  };
  if (Array.isArray(image)) {
    // array
    if (image.length === 0) return <div>{title}</div>;
    if (image.length === 1) {
      const imageData = `data:image/jpeg;base64,${Buffer.from(
        image[0].file.data
      ).toString("base64")}`;
      return (
        <div>
          <div className="bg-slate-100">
            <img
              style={style}
              className="item-center p-2"
              src={imageData}
              alt={title}
            />
          </div>
          {deleteImages && (
            <button
              className="absolute top-40 left-0 cursor-pointer hover:text-blue-600"
              onClick={(event: any) =>
                deleteImages(event, productId ?? "", image[0]._id)
              }
            >
              Delete
            </button>
          )}
        </div>
      );
    }
    if (image.length > 1) {
      const imageData = image.map((image) => {
        return image.file && image.file.data
          ? `data:image/jpeg;base64,${Buffer.from(image.file.data).toString(
              "base64"
            )}`
          : "";
      });
      return (
        <div className="flex flex-col justify-center">
          <div
            className={
              "flex justify-center items-center min-w-fit bg-slate-100"
            }
          >
            {showBtn && (
              <button className="bg-transparent" onClick={handlePrevImage}>
                <FontAwesomeIcon icon={faLeftLong} />
              </button>
            )}
            <img
              style={style}
              className="item-center p-6"
              src={imageData[currentImageIndex]}
              alt={title}
            />
            {showBtn && (
              <button className="bg-transparent" onClick={handleNextImage}>
                <FontAwesomeIcon icon={faRightLong} />
              </button>
            )}
          </div>
          {deleteImages && (
            <button
              className="absolute top-40 left-0 cursor-pointer hover:text-blue-600"
              onClick={(event: any) =>
                deleteImages(
                  event,
                  productId ?? "",
                  image[currentImageIndex]._id
                )
              }
            >
              Delete
            </button>
          )}
        </div>
      );
    }
  } else {
    // not an array
    if (!image.file?.data) return <div>{title}</div>;

    const imageData = `data:image/jpeg;base64,${Buffer.from(
      image.file.data
    ).toString("base64")}`;
    return (
      <div>
        <img
          style={style}
          className="item-center p-6"
          src={imageData}
          alt={title}
        />
        {deleteImages && (
          <button
            onClick={(event: any) =>
              deleteImages(event, productId ?? "", image._id)
            }
          >
            Delete
          </button>
        )}
      </div>
    );
  }
};

export default DbImage;
