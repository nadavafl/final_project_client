import loadingGif from "../../assets/loading.gif";

const Loading = () => (
    <div
        style={{ backgroundColor: "#E5EFF1" }}
        className="min-h-screen">
        <h1 className="text-6xl text-center mb-10">Loading...</h1>
        <img
            className="w-1/2 h-1/3 mx-auto"
            src={loadingGif}
            alt="Loading..."
        />
  </div>
);

export default Loading;
