import { FieldErrors, UseFormRegister } from "react-hook-form";
import { ILogin } from "../../types/models";
import { useContext } from "react";
import { ThemeContext } from "../../contexts/ThemeContext";

const FormLogin = ({
  register,
  errors,
}: {
  register: UseFormRegister<ILogin>;
  errors: FieldErrors<ILogin>;
}) => {
  const { darkMode } = useContext(ThemeContext);
  return (
    <>
      <label className="flex flex-col justify-start w-1/4">
        Email:
        <input
          {...register("email")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 m-5 w-full"
          type="text"
          placeholder="Email"
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.email && (
            <p className="text-xl text-red-800">
              {"Email is required. Must be valid email"}
            </p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start w-1/4">
        Password:
        <input
          {...register("password")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 m-5 w-full"
          type="password"
          placeholder="Password"
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.password && (
            <p className="text-lg text-red-800">
              {
                "Password is required. Must be 7-20 characters, contain at least: one uppercase and one lowercase letter, one number and one special character"
              }
            </p>
          )}
        </div>
      </label>
    </>
  );
};

export default FormLogin;
