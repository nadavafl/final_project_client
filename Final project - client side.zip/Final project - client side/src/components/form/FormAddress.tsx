import { IAddress, ISupplierInput, IUserInput } from "../../types/models";
import { UseFormRegister, FieldErrors } from "react-hook-form";

const FormAddress = ({
  register,
  errors,
  values,
  useDefaultValue,
  isDisabled,
  darkMode,
}: {
  register: UseFormRegister<IAddress | any>;
  errors: FieldErrors<IUserInput>;
  values: IUserInput | ISupplierInput;
  useDefaultValue: boolean;
    isDisabled?: boolean;
  darkMode?: boolean | any;
}) => {
  const address = values?.address || {};
  return (
    <>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Country:
        <input
          {...register("address.country")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full "
          type="text"
          placeholder={useDefaultValue ? undefined : address.country}
          defaultValue={useDefaultValue ? address.country : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.address?.country && (
            <p className="text-xl text-red-800">{"Country is required"}</p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        State:
        <input
          {...register("address.state")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full "
          type="text"
          placeholder={useDefaultValue ? undefined : address.state}
          defaultValue={useDefaultValue ? address.state : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }} />
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *City:
        <input
          {...register("address.city")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full"
          type="text"
          placeholder={useDefaultValue ? undefined : address.city}
          defaultValue={useDefaultValue ? address.city : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.address?.city && (
            <p className="text-xl text-red-800">{"City is required"}</p>
          )}
        </div>
      </label>
      <label className="flex flex-col justify-start h-full w-2/3">
        *Street:
        <input
          {...register("address.street")}
          style={{ backgroundColor: darkMode && "#1f2937" }}
          className="p-5 mt-5 w-full "
          type="text"
          placeholder={useDefaultValue ? undefined : address.street}
          defaultValue={useDefaultValue ? address.street : undefined}
          disabled={isDisabled}
        />
        <div style={{ height: "20px", marginBottom: "10px" }}>
          {errors.address?.street && (
            <p className="text-xl text-red-800">{"Street is required"}</p>
          )}
        </div>
      </label>
      <div className="flex flex-raw justify-start h-full w-2/3 mt-1">
        <label className="flex flex-col mr-3 justify-start h-full w-1/2">
          *House num:
          <input
            {...register("address.houseNumber")}
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 mt-5 mr-5 w-full "
            type="text"
            placeholder={useDefaultValue ? undefined : address.houseNumber}
            defaultValue={useDefaultValue ? address.houseNumber : undefined}
            disabled={isDisabled}
          />
          <div style={{ height: "20px", marginBottom: "2px" }}>
            {errors.address?.houseNumber && (
              <p className="text-xl text-red-800">
                {"House number is required"}
              </p>
            )}
          </div>
        </label>
        <label className="flex flex-col justify-start h-full w-1/2">
          *Postal code:
          <input
            {...register("address.postalCode")}
            style={{ backgroundColor: darkMode && "#1f2937" }}
            className="p-5 mt-5 w-full "
            type="text"
            placeholder={useDefaultValue ? undefined : address.postalCode}
            defaultValue={useDefaultValue ? address.postalCode : undefined}
            disabled={isDisabled}
          />
          <div style={{ height: "20px", marginBottom: "2px" }}>
            {errors.address?.postalCode && (
              <p className="text-xl text-red-800">
                {"Postal code is required"}
              </p>
            )}
          </div>
        </label>
      </div>
    </>
  );
};

export default FormAddress;
