import { Link } from "react-router-dom";
import Navbar from "../../layout/Navbar";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMoon, faSun } from "@fortawesome/free-solid-svg-icons";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { faCartShopping } from "@fortawesome/free-solid-svg-icons/faCartShopping";

const NonGuestHeader = ({
  id,
  line,
  handleSearch,
  searchInput,
  setSearchInput,
  toggleDarkMode,
  darkMode,
  setAvatarDropdown,
  avatarDropdown,
  userImage,
  userEmail,
  logOut,
  user,
  userName,
  setCartDropdown,
  cartDropdown,
}: {
  id: string;
  line: JSX.Element;
  handleSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  searchInput: string;
  setSearchInput: React.Dispatch<React.SetStateAction<string>>;
  toggleDarkMode: () => void;
  darkMode: boolean | any;
  setAvatarDropdown: React.Dispatch<React.SetStateAction<boolean>>;
  avatarDropdown: boolean;
  userImage: string;
  userEmail: string;
  logOut: () => void;
  user: string;
  userName: string;
  setCartDropdown: React.Dispatch<React.SetStateAction<boolean>>;
  cartDropdown: boolean;
}) => {
  return (
    <div className="flex flex-col flex-wrap">
      <div className="flex flex-row gap-10 bg-gray-800 p-5 text-4xl font-bold text-white">
        <Link className="flex items-center" to={`/${id}`}>
          METRO{line}
        </Link>
        <div className="flex-1" />
        <div className="flex w-1/2">
          <form onSubmit={handleSearch} className="flex w-full">
            <input
              style={{
                backgroundColor: darkMode && "#1f2937",
                color: darkMode && "#f3f4f6",
              }}
              className="text-black rounded-l-full py-2 w-full px-6 border-2 border-r-0 border-gray-300 focus:outline-none focus:border-yellow-300"
              type="text"
              placeholder="Search Metroline"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
            />
            <button
              type="submit"
              className="bg-yellow-300 hover:bg-yellow-500 text-white font-bold py-2 px-4 rounded-r-full"
            >
              <FontAwesomeIcon icon={faSearch} />
            </button>
          </form>
        </div>
        <div className="flex-1" />
        <button className="" onClick={toggleDarkMode}>
          <FontAwesomeIcon icon={!darkMode ? faMoon : faSun} />
        </button>
        <div
          className="relative"
          onMouseEnter={() => setCartDropdown(true)}
          onMouseLeave={() => setCartDropdown(false)}
        >
          <div
            className="flex -space-x-1 overflow-hidden cursor-pointer h-full"
            onClick={() => setCartDropdown(!cartDropdown)}
          >
            <div className="flex items-center text-5xl">
              <FontAwesomeIcon icon={faCartShopping} />
            </div>
          </div>
          {cartDropdown && (
            <div className="absolute top-16 right-2 mt-2 w-48 bg-white border border-gray-200 divide-y divide-gray-100 rounded-md shadow-lg">
              <div className="px-4 py-3">
                <Link
                  to={"/myCarts"}
                  className="text-sm text-gray-700 block px-4 py-2 hover:bg-gray-200"
                  onClick={() => setCartDropdown(!cartDropdown)}
                >
                  My carts
                </Link>
                <Link
                  className="text-sm text-gray-700 block px-4 py-2 hover:bg-gray-200"
                  to={"/purchasedCarts"}
                  onClick={() => setCartDropdown(!cartDropdown)}
                >
                  Purchased carts
                </Link>
              </div>
            </div>
          )}
        </div>
        <div
          className="relative pr-2"
          onMouseEnter={() => setAvatarDropdown(true)}
          onMouseLeave={() => setAvatarDropdown(false)}
        >
          <div
            className="flex -space-x-1 overflow-hidden cursor-pointer"
            onClick={() => setAvatarDropdown(!avatarDropdown)}
          >
            <img
              className="inline-block w-20 h-20 rounded-full border-4 border-yellow-300"
              src={userImage ?? ""}
              alt=""
            />
          </div>
          {avatarDropdown && (
            <div className="absolute right-0 w-48 bg-white border border-gray-200 divide-y divide-gray-100 rounded-md shadow-lg">
              <div className="px-4 py-3">
                <p className="text-sm font-medium text-gray-900">{userEmail}</p>
              </div>
              <div className="py-1">
                <Link
                  className="text-sm text-gray-700 block px-4 py-2 hover:bg-gray-100"
                  to={`/update/${id}`}
                  onClick={() => setAvatarDropdown(!avatarDropdown)}
                >
                  My Profile
                </Link>
                <Link
                  className="text-sm text-gray-700 block px-4 py-2 hover:bg-gray-100"
                  to="/"
                  onClick={logOut}
                >
                  Sign out
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
      <div>
        <Navbar user={user} userName={userName} />
      </div>
    </div>
  );
};

export default NonGuestHeader;
