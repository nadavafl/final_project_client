import { Link } from "react-router-dom";
import Navbar from "../../layout/Navbar";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMoon, faSun } from "@fortawesome/free-solid-svg-icons";
import { faSearch } from "@fortawesome/free-solid-svg-icons";

const GuestHeader = ({
  id,
  line,
  handleSearch,
  searchInput,
  setSearchInput,
  toggleDarkMode,
  darkMode,
  user,
  setIsOpen,
  isOpen,
}: {
  id: string;
  line: JSX.Element;
  handleSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  searchInput: string;
  setSearchInput: React.Dispatch<React.SetStateAction<string>>;
  toggleDarkMode: () => void;
  darkMode: boolean | any;
  user: string;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isOpen: boolean;
}) => {
  return (
    <div className="flex flex-col flex-wrap">
      <div className="flex flex-row gap-9 bg-gray-800 p-5 text-4xl font-bold text-white">
        <Link className="flex items-center" to={`/${id}`}>
          METRO{line}
        </Link>
        <div className="flex-1" />
        <div className="flex w-1/2">
          <form onSubmit={handleSearch} className="flex w-full">
            <input
              style={{
                backgroundColor: darkMode && "#1f2937",
                color: darkMode && "#f3f4f6",
              }}
              className="text-black rounded-l-full py-2 w-full px-6 border-2 border-r-0 border-gray-300 focus:outline-none focus:border-yellow-300"
              type="text"
              placeholder="Search Metroline"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
            />
            <button
              type="submit"
              className="bg-yellow-300 hover:bg-yellow-500 text-white font-bold py-2 px-4 rounded-r-full"
            >
              <FontAwesomeIcon icon={faSearch} />
            </button>
          </form>
        </div>
        <div className="flex-1" />
        <button className="" onClick={toggleDarkMode}>
          <FontAwesomeIcon icon={!darkMode ? faMoon : faSun} />
        </button>
        <div
          className="relative"
          onMouseEnter={() => setIsOpen(true)}
          onMouseLeave={() => setIsOpen(false)}
        >
          <div className="flex -space-x-1 overflow-hidden cursor-pointer h-full">
            <div className="mb-1">
              <p className="text-xl">Hello guest,</p>
              <p>sign here</p>
            </div>
          </div>
          {isOpen && (
            <div className="absolute right-5 mt-0 w-36 bg-white border border-gray-200 divide-y divide-gray-100 rounded-md shadow-lg">
              <div className="py-1">
                <Link
                  className="text-base text-gray-700 block px-4 py-2 hover:bg-gray-100"
                  to="/login"
                  onClick={() => setIsOpen(!isOpen)}
                >
                  Login
                </Link>
                <Link
                  className="text-base text-gray-700 block px-4 py-2 hover:bg-gray-100"
                  to="/register"
                  onClick={() => setIsOpen(!isOpen)}
                >
                  Register
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
      <div>
        <Navbar user={user} />
      </div>
    </div>
  );
};

export default GuestHeader;
