import { Link } from "react-router-dom";
import { IProduct } from "../../types/models";
import DbImage from "../web/ImageHandler";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-regular-svg-icons";

const MainProduct = ({
  product,
  id,
  disable,
  onAddToFavourites,
  darkMode,
}: {
  product: IProduct;
  id: string | undefined;
  disable?: boolean;
  onAddToFavourites?: (itemId: string, page: string) => void;
  darkMode: boolean | any;
}) => {
  return (
    <div
      className="flex flex-wrap items-center justify-center 
  w-full sm:w-1/2 md:w-1/3 lg:w-1/2 xl:w-1/3"
      key={product._id}
    >
      <div
        style={{ backgroundColor: darkMode && "#1f2937" }}
        id="cardToPick"
        className="block items-center justify-center m-3 p-2 min-h-full w-2/3 font-semibold"
      >
        <Link
          className="flex flex-col items-center justify-center m-3 p-2"
          to={`/supplier/${id}/${product.supplier_id}`}
        >
          {!disable && (
            <DbImage
              image={product.images}
              title={product.title}
              style={{
                maxHeight: "35rem",
                minHeight: "16.5rem",
                width: "500px",
                height: "350px",
              }}
            />
          )}
          <h2>{String(product.title)}</h2>
          <h2>{product.description}</h2>
          <h2>{product.price}</h2>
        </Link>
        {disable && (
          <button
            onClick={() =>
              onAddToFavourites &&
              onAddToFavourites(product._id ?? "", "product")
            }
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-4xl"
          >
            <FontAwesomeIcon icon={faStar} />
          </button>
        )}
      </div>
    </div>
  );
};

export default MainProduct;
