import { Link } from "react-router-dom";
import { ISupplier } from "../../types/models";
import DbImage from "../web/ImageHandler";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faThumbsUp } from "@fortawesome/free-regular-svg-icons/faThumbsUp";
import { faStar } from "@fortawesome/free-regular-svg-icons/faStar";

const MainSupplier = ({
  supplier,
  id,
  disable,
  onAddToFavourites,
  darkMode,
}: {
  supplier: ISupplier;
  id: string | undefined;
  disable?: boolean;
  onAddToFavourites?: (itemId: string, page: string) => void;
  darkMode: boolean | any;
}) => {
  return (
    <div
      className="flex flex-row items-center justify-center 
  w-full min-h-full sm:w-1/2 md:w-1/3 lg:w-1/2 xl:w-1/3 relative"
      key={supplier._id}
    >
      <div
        style={{ backgroundColor: darkMode && "#1f2937" }}
        id="cardToPick"
        className="block items-center justify-center m-3 p-2 min-h-full w-2/3"
      >
        <Link to={`/supplier/${id}/${supplier._id}`}>
          <h1 className="text-center font-extrabold text-4xl">
            {supplier.title}
          </h1>
          <h2 className="text-center my-5 text-2xl">{supplier.subtitle}</h2>
          <h2 className="text-center my-5 text-2xl">{supplier.email}</h2>
          <h2 className="text-center my-5 text-2xl">{supplier.phone}</h2>
          <h2 className="text-center my-5 text-2xl">
            {supplier.businessType?.type}
          </h2>

          {!disable && supplier.image?.file?.data ? (
            <DbImage
              image={supplier.image}
              title={supplier.title}
              showBtn={false}
              style={{
                maxHeight: "35rem",
                minHeight: "16.5rem",
                width: "650px",
                height: "400px",
              }}
            />
          ) : (
            ""
          )}
        </Link>
        {!disable ? (
          (supplier.likes?.length ?? 0) >= 0 && (
            <div className="">
              {`${supplier.likes?.length ?? 0}`}
              <FontAwesomeIcon icon={faThumbsUp} />
            </div>
          )
        ) : (
          <button
            onClick={() =>
              onAddToFavourites &&
              onAddToFavourites(supplier._id ?? "", "supplier")
            }
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-4xl"
          >
            <FontAwesomeIcon icon={faStar} />
          </button>
        )}
      </div>
    </div>
  );
};

export default MainSupplier;
