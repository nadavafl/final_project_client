import { Link } from "react-router-dom";
import { IBusinessType } from "../../types/models";

const MainCategory = ({
  category,
  darkMode,
}: {
  category: IBusinessType;
  darkMode: boolean | any
}) => {
  return (
    <Link
      style={{ backgroundColor: darkMode && "#1f2937" }}
      id="cardToPick"
      className="flex items-center justify-center m-6 p-2 shadow-2xl w-1/4 h-1/4 text-3xl font-bold"
      to={`/byCategory/${category}`}
      key={`${category}`}
    >
      {String(category)}
    </Link>
  );
};

export default MainCategory;
