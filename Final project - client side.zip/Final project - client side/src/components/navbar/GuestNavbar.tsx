import { Link } from "react-router-dom";
import { showAlert } from "../../utils/alert";

const GuestNavbar = ({ linkStyle }: { linkStyle: string }) => {
  return (
    <>
      <nav className="flex flex-wrap gap-10 bg-blue-600 p-5 text-3xl font-bold text-white">
        <div className="flex-1" />
        <Link className={linkStyle} to="/aboutUs">
          About Us
        </Link>
        <Link
          className={linkStyle}
          to="/login"
          onClick={() => showAlert("Please sign in first", "To add favorites")}
        >
          Favorites
        </Link>
        <Link className={linkStyle} to="/advertise">
          Advertising
        </Link>
        <Link className={linkStyle} to="/contact">
          Contact
        </Link>
        <div className="flex-1" />
      </nav>
    </>
  );
};

export default GuestNavbar;
