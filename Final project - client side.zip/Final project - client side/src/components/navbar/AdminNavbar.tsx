import { useNavigate } from "react-router-dom";

const AdminNavbar = ({
  linkStyle,
  userName,
}: {
  linkStyle: string;
  userName: string | undefined;
}) => {
  const navigate = useNavigate();
  return (
    <>
      <nav className="flex flex-wrap gap-10 bg-blue-600 p-5 text-3xl font-bold text-white">
        <div className="flex-1" />
        <div
          className={`${linkStyle} ml-36 cursor-pointer`}
          onClick={() => navigate("/favorites")}
        >
          Favorites
        </div>
        <div
          className={`${linkStyle} cursor-pointer`}
          onClick={() => navigate("/adminLists/users")}
        >
          Users list
        </div>
        <div
          className={`${linkStyle} cursor-pointer`}
          onClick={() => navigate("/adminLists/suppliers")}
        >
          Suppliers list
        </div>
        <div
          className={`${linkStyle} cursor-pointer`}
          onClick={() => navigate("/adminLists/carts")}
        >
          Carts list
        </div>
        <div className="flex-1" />
        <div>Hello, {`${userName}`}</div>
      </nav>
    </>
  );
};

export default AdminNavbar;
