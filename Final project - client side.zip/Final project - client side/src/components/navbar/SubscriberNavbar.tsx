import { Link } from "react-router-dom";

const SubscriberNavbar = ({
  userName,
  linkStyle,
  user,
}: {
  linkStyle: string;
  userName: string | undefined;
  user: string;
}) => {
  return (
    <>
      <nav className="flex flex-wrap gap-10 bg-blue-600 p-5 text-3xl font-bold text-white w-full">
        <div className="flex-1" />
        <Link className={`${linkStyle} ml-36`} to="/aboutUs">
          About Us
        </Link>
        <Link className={linkStyle} to="/favorites">
          Favorites
        </Link>
        <Link className={linkStyle} to="/advertise">
          Advertising
        </Link>
        <Link className={linkStyle} to="/contact">
          Contact
        </Link>
        {user === "BusinessUser" && (
          <>
            <Link className={linkStyle} to="/createSupplier">
              Create supplier
            </Link>
            <Link className={linkStyle} to="/myBusinesses">
              My businesses
            </Link>
          </>
        )}
        <div className="flex-1" />
        <div>Hello, {`${userName}`}</div>
      </nav>
    </>
  );
};

export default SubscriberNavbar;
