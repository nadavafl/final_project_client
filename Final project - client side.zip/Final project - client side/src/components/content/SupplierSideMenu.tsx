import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { handleMouseEnter, handleMouseLeave } from "../../helpers/darkModeHover";
import { faBars, faXmark } from "@fortawesome/free-solid-svg-icons";

const SupplierSideMenu = ({
  sideMenu,
  setSideMenu,
  setSupplierDetails,
  setAddProduct,
  setUpdateInfo,
  setDeliveryInfo,
  setUploadImage,
  setDeleteAccount,
  setCarts,
  darkMode,
}: {
  sideMenu: boolean;
  setSideMenu: (sideMenu: boolean) => void;
  setSupplierDetails: (supplierDetails: boolean) => void;
  setAddProduct: (addProduct: boolean) => void;
  setUpdateInfo: (updateInfo: boolean) => void;
  setDeliveryInfo: (deliveryInfo: boolean) => void;
  setUploadImage: (uploadImage: boolean) => void;
  setDeleteAccount: (deleteAccount: boolean) => void;
  setCarts: (carts: boolean) => void;
  darkMode: boolean | any;
  }) => {
   const mouseEnterHandler = handleMouseEnter(darkMode);
   const mouseLeaveHandler = handleMouseLeave(darkMode);
  return (
      <div className="flex flex-col text-3xl absolute left-0 text-left w-1/5 mx-3">
        <p onClick={() => setSideMenu(!sideMenu)} className="cursor-pointer">
          {sideMenu ? (
            <FontAwesomeIcon icon={faXmark} />
          ) : (
            <FontAwesomeIcon icon={faBars} />
          )}
        </p>
        {sideMenu && (
          <>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-3/5 p-1 cursor-pointer hover:bg-slate-200 border-r-2 border-blue-500"
              onClick={() => {
                setSupplierDetails(true);
                setAddProduct(false);
                setUpdateInfo(false);
                setDeliveryInfo(false);
                setUploadImage(false);
                setDeleteAccount(false);
                setCarts(false);
              }}
            >
              Supplier
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-3/5 p-1 cursor-pointer hover:bg-slate-200 border-r-2 border-blue-500"
              onClick={() => {
                setUpdateInfo(true);
                setAddProduct(false);
                setDeliveryInfo(false);
                setUploadImage(false);
                setDeleteAccount(false);
                setCarts(false);
                setSupplierDetails(false);
              }}
            >
              Update details
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-3/5 p-1 cursor-pointer hover:bg-slate-200 border-r-2 border-blue-500"
              onClick={() => {
                setDeliveryInfo(true);
                setAddProduct(false);
                setUpdateInfo(false);
                setUploadImage(false);
                setDeleteAccount(false);
                setCarts(false);
                setSupplierDetails(false);
              }}
            >
              Update delivery
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-3/5 p-1 cursor-pointer hover:bg-slate-200 border-r-2 border-blue-500"
              onClick={() => {
                setUploadImage(true);
                setAddProduct(false);
                setUpdateInfo(false);
                setDeliveryInfo(false);
                setDeleteAccount(false);
                setCarts(false);
                setSupplierDetails(false);
              }}
            >
              Upload image
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-3/5 p-1 cursor-pointer hover:bg-slate-200 border-r-2 border-blue-500"
              onClick={() => {
                setAddProduct(true);
                setUpdateInfo(false);
                setDeliveryInfo(false);
                setDeleteAccount(false);
                setUploadImage(false);
                setCarts(false);
                setSupplierDetails(false);
              }}
            >
              Add product
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-3/5 p-1 cursor-pointer hover:bg-slate-200 border-r-2 border-blue-500"
              onClick={() => {
                setCarts(true);
                setAddProduct(false);
                setUploadImage(false);
                setUpdateInfo(false);
                setDeliveryInfo(false);
                setDeleteAccount(false);
                setSupplierDetails(false);
              }}
            >
              Carts
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-3/5 p-1 cursor-pointer hover:bg-slate-200 border-r-2 border-blue-500"
              onClick={() => {
                setDeleteAccount(true);
                setAddProduct(false);
                setUploadImage(false);
                setUpdateInfo(false);
                setDeliveryInfo(false);
                setCarts(false);
                setSupplierDetails(false);
              }}
            >
              Delete account
            </div>
          </>
        )}
      </div>
  );
};

export default SupplierSideMenu;
