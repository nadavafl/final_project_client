import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { handleMouseEnter, handleMouseLeave } from "../../helpers/darkModeHover";
import { faBars, faXmark } from "@fortawesome/free-solid-svg-icons";

const UserSideMenu = ({
  sideMenu,
  setSideMenu,
  setUserDetails,
  setUpdateForm,
  setUpdateSubscription,
  setChangePassword,
  setUploadImage,
  setDeleteAccount,
  darkMode,
}: {
  sideMenu: boolean;
  setSideMenu: (sideMenu: boolean) => void;
  setUserDetails: (userDetails: boolean) => void;
  setUpdateForm: (updateForm: boolean) => void;
  setUpdateSubscription: (updateSubscription: boolean) => void;
  setChangePassword: (changePassword: boolean) => void;
  setUploadImage: (uploadImage: boolean) => void;
  setDeleteAccount: (deleteAccount: boolean) => void;
  darkMode: boolean | any;
  }) => {
  const mouseEnterHandler = handleMouseEnter(darkMode);
  const mouseLeaveHandler = handleMouseLeave(darkMode);
  
  return (
    <div className="flex flex-col h-full w-full items-center">
      <div className="flex flex-col text-3xl absolute left-0 text-left w-1/2 mx-3">
        <p onClick={() => setSideMenu(!sideMenu)} className="cursor-pointer">
          {sideMenu ? (
            <FontAwesomeIcon icon={faXmark} />
          ) : (
            <FontAwesomeIcon icon={faBars} />
          )}
        </p>
        {sideMenu && (
          <>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-1/5 p-1 cursor-pointer hover:bg-slate-100 border-r-2 border-blue-500"
              onClick={() => {
                setUserDetails(true);
                setUpdateForm(false);
                setUpdateSubscription(false);
                setChangePassword(false);
                setUploadImage(false);
                setDeleteAccount(false);
              }}
            >
              My details
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-1/5 p-1 cursor-pointer hover:bg-slate-100 border-r-2 border-blue-500"
              onClick={() => {
                setUpdateForm(true);
                setUpdateSubscription(false);
                setChangePassword(false);
                setUploadImage(false);
                setDeleteAccount(false);
                setUserDetails(false);
              }}
            >
              Update details
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-1/5 p-1 cursor-pointer hover:bg-slate-100 border-r-2 border-blue-500"
              onClick={() => {
                setUpdateSubscription(true);
                setUpdateForm(false);
                setChangePassword(false);
                setUploadImage(false);
                setDeleteAccount(false);
                setUserDetails(false);
              }}
            >
              Subscription
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-1/5 p-1 cursor-pointer hover:bg-slate-100 border-r-2 border-blue-500"
              onClick={() => {
                setChangePassword(true);
                setUpdateForm(false);
                setUpdateSubscription(false);
                setUploadImage(false);
                setDeleteAccount(false);
                setUserDetails(false);
              }}
            >
              Password
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-1/5 p-1 cursor-pointer hover:bg-slate-100 border-r-2 border-blue-500"
              onClick={() => {
                setUploadImage(true);
                setUpdateForm(false);
                setUpdateSubscription(false);
                setChangePassword(false);
                setDeleteAccount(false);
                setUserDetails(false);
              }}
            >
              Upload picture
            </div>
            <div
              style={{ backgroundColor: darkMode && "#1f2937" }}
              onMouseEnter={mouseEnterHandler}
              onMouseLeave={mouseLeaveHandler}
              className="w-1/5 p-1 cursor-pointer hover:bg-slate-100 border-r-2 border-blue-500"
              onClick={() => {
                setDeleteAccount(true);
                setUploadImage(false);
                setUpdateForm(false);
                setUpdateSubscription(false);
                setChangePassword(false);
                setUserDetails(false);
              }}
            >
              Delete account
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default UserSideMenu;
