import { useEffect, useState } from "react";
import { ISupplier } from "../../types/models";
import DbImage from "../web/ImageHandler";
import { useHandleLike } from "../../hooks/useHandleLike";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons/faStar";
import { faThumbsUp } from "@fortawesome/free-regular-svg-icons/faThumbsUp";

const SupplierInfo = ({
  supplier,
  onAddToFavourites,
  userRole,
  refetch,
  isFavorite,
}: {
  supplier: ISupplier;
  onAddToFavourites: (itemId: string, page: string) => void;
  userRole: string;
  refetch: () => void;
  isFavorite: (
    itemId: string,
    type: "Supplier" | "Product"
  ) => Promise<boolean>;
}) => {
  const { handleLike } = useHandleLike({
    id: supplier._id,
    refetch,
    type: "Supplier",
  });

  const [isFav, setIsFav] = useState(false);
  useEffect(() => {
    const checkFavorite = async () => {
      const fav = await isFavorite(supplier._id ?? "", "Supplier");
      setIsFav(fav);
    };
    checkFavorite();
  }, [onAddToFavourites]);

  return (
    <div className="flex flex-col items-center mt-20 space-y-8 text-3xl">
      <h1>
        <b>{supplier.title}</b>
      </h1>
      <div className="w-1/3 h-1/3">
        <DbImage
          image={supplier.image}
          title={supplier.title}
          showBtn={false}
        />
      </div>
      <h2 className="text-6xl">{supplier.subtitle}</h2>
      <h3 className="text-4xl w-2/3 text-center">{supplier.description}</h3>
      <h2 className="text-5xl">Contact information:</h2>
      <p>{`${supplier.address.street} ${supplier.address.houseNumber}`}</p>
      <p>{`${supplier.address.city}, ${supplier.address.state}, ${supplier.address.country}`}</p>
      <p>Postal code: {supplier.address.postalCode}</p>
      <p>Phone number: {supplier.phone}</p>
      <p>Email: {supplier.email}</p>
      <p>Website: {supplier.web}</p>
      <h2 className="text-5xl">Order details:</h2>
      <p>
        Delivery times and locations: {supplier.orderDetail?.deliveryAreaDays}
      </p>
      <p>Minimum order: ${supplier.orderDetail?.minOrder}</p>
      <p>Delivery cost: ${supplier.orderDetail?.deliveryCost}</p>
      <button
        onClick={() => onAddToFavourites(supplier._id ?? "", "supplier")}
        className={
          isFav
            ? "bg-yellow-400 hover:bg-yellow-700  font-bold py-2 px-4 rounded text-4xl border-solid border-4 border-green-700	"
            : "bg-transparent hover:bg-yellow-500  font-bold py-2 px-4 rounded text-4xl  border-solid border-4 border-green-700	"
        }
      >
        {isFav ? (
          <FontAwesomeIcon icon={faStar} beat />
        ) : (
          <FontAwesomeIcon icon={faStar} />
        )}
      </button>
      {userRole === "guest" ? (
        <p className="text-4xl">
          {supplier.likes?.length} <FontAwesomeIcon icon={faThumbsUp} />
        </p>
      ) : (
        <button
          onMouseOver={(e) => (e.currentTarget.style.color = "#FCD53F")}
          onMouseOut={(e) => (e.currentTarget.style.color = "")}
          onClick={handleLike}
          className="text-4xl"
        >
          {supplier.likes?.length} <FontAwesomeIcon icon={faThumbsUp} />
        </button>
      )}
    </div>
  );
};

export default SupplierInfo;
