import { ICart, IProduct } from "../../types/models";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { useIncrementItem } from "../../hooks/useIncrementItem";
import { supplierAlerts } from "../../helpers/supplierAlerts";
import DbImage from "../web/ImageHandler";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCartShopping, faMinus, faPlus, faStar, faXmark } from "@fortawesome/free-solid-svg-icons";

const ProductFullCard = ({
  className,
  userId,
  supplierId,
  userToken,
  product,
  refetch,
  carts,
  setSelectedProduct,
  onAddToFavourites,
  isFavorite,
  darkMode,
}: {
  className: string;
  userId: string;
  supplierId: string;
  userToken: string;
  product: IProduct;
  refetch: () => void;
  carts: ICart[];
  setSelectedProduct: Dispatch<SetStateAction<IProduct | null>>;
  onAddToFavourites: (
    itemId: string,
    page: string,
    selectedProduct: IProduct
  ) => void;
  isFavorite: (
    itemId: string,
    type: "Supplier" | "Product"
    ) => Promise<boolean>;
  darkMode: boolean | any;
}) => {
  const [cardBtn, setCardBtn] = useState(false);
  const userCart = carts.find((cart) => cart.supplier_id === supplierId);
  const cartItem = userCart?.items.find((item) => item._id === product._id);

  useEffect(() => {
    if (cartItem?.quantity) {
      setCardBtn(true);
    } else {
      setCardBtn(false);
    }
  }, [cartItem?.quantity]);

  const [isFav, setIsFav] = useState(false);

  useEffect(() => {
    const checkFavorite = async () => {
      const fav = await isFavorite(product._id ?? "", "Product");
      setIsFav(fav);
    };
    checkFavorite();
  }, [onAddToFavourites]);

  const incrementItem = useIncrementItem(userToken, refetch);

  const onAddReduce = (productId: string, quantity: number) =>
    incrementItem.mutate({
      userId: userId ?? "",
      supplierId: supplierId ?? "",
      productId,
      quantity,
    });

  const exitProduct = () => {
    setSelectedProduct(null);
  };

  return (
    <div
      style={{ backgroundColor: darkMode && "#1f2937" }}
      id="card"
      className={`flex flex-col text-center justify-center p-2 text-3xl font-bold w-full sm:w-1/2 md:w-1/3 lg:w-1/3 xl:w-1/3 ${className} relative`}
    >
      <div className="flex flex-col text-center justify-center items-center">
        <button
          className="absolute w-1/12 top-3 right-3 bg-red-500 text-white p-2 rounded-xl text-2xl hover:bg-red-700"
          onClick={exitProduct}
        >
          <FontAwesomeIcon icon={faXmark} />
        </button>
        <div className="flex w-2/3 h-2/3 text-center justify-center items-center">
          <DbImage
            image={product.images}
            title={product.title}
            showBtn={true}
            style={{
              maxHeight: "35rem",
              minHeight: "16.5rem",
              width: "700px",
              height: "500px",
            }}
          />
        </div>
        <div className="space-y-3 my-10">
          <p>{product.title}</p>
          <p>{product.description}</p>
          <p>{product.price}$</p>
          <div className="flex justify-center space-x-3">
            {!product.inStock ? (
              <p className="bg-red-500 p-2 rounded-3xl">Out of stock</p>
            ) : (
              <p className="bg-green-500 p-2 rounded-3xl"> In stock</p>
            )}
            {product.inStock && (product.stock ?? 0) < 10 && (
              <p className="bg-orange-500 p-2 rounded-3xl">
                Only {product.stock} left
              </p>
            )}
          </div>
        </div>
      </div>
      <div className="flex justify-center w-full mb-6 space-x-8">
        <button
          onClick={() => onAddToFavourites(product._id, "product", product)}
          className={
            isFav
              ? "bg-yellow-400 hover:bg-yellow-700  font-bold py-2 px-4 rounded text-4xl border-solid border-4 border-green-700	"
              : "bg-transparent hover:bg-yellow-500  font-bold py-2 px-4 rounded text-4xl  border-solid border-4 border-green-700	"
          }
        >
          {isFav ? (
            <FontAwesomeIcon icon={faStar} beat />
          ) : (
            <FontAwesomeIcon icon={faStar} />
          )}
        </button>
        {!cardBtn ? (
          product.inStock && (
            <button
              className="bg-transparent hover:bg-yellow-400 font-bold py-2 px-4 rounded text-4xl  border-solid border-4 border-green-700"
              onClick={() => {
                userId === "guest"
                  ? supplierAlerts.isGuestCart(product)
                  : (setCardBtn(true), onAddReduce(product._id, +1));
              }}
            >
              <FontAwesomeIcon icon={faCartShopping} />
            </button>
          )
        ) : (
          <div className="flex justify-center w-1/3 h-2/3 m-3 items-center">
            <button
              className="bg-transparent font-bold py-2 px-4 rounded text-4x w-1/4"
              onClick={() => onAddReduce(product._id, -1)}
            >
              <FontAwesomeIcon icon={faMinus} />
            </button>
            <input
              style={{ backgroundColor: darkMode && "#1f2937" }}
              className="w-1/6 h-full text-center m-3 no-spinners border-0"
              type="number"
              id="number"
              readOnly
              value={cartItem?.quantity || 0}
              onChange={(e) => onAddReduce(product._id, +e.target.value)}
            />
            <button
              className="bg-transparent font-bold py-2 px-4 rounded text-4x w-1/4"
              onClick={() => onAddReduce(product._id, +1)}
            >
              <FontAwesomeIcon icon={faPlus} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductFullCard;
