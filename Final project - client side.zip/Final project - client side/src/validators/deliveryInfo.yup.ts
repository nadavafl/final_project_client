import * as yup from "yup";

export const yupDeliveryInfoSchema = yup.object().shape({
  orderDetail: yup.object().shape({
    deliveryAreaDays: yup.string().min(2).max(100),
    minOrder: yup.number().min(0),
    deliveryCost: yup.number().min(0),
  }),
});
