import * as yup from "yup";
import { patterns } from "./regexPatterns";
import { IUserInput } from "../types/models";

export const yupUserSchema = yup.object<IUserInput>().shape({
  name: yup.object().shape({
    first: yup.string().min(2).max(50).required(),
    middle: yup.string().min(0).max(50).default(""),
    last: yup.string().min(2).max(50).required(),
  }),
  phone: yup
    .string()
    .min(9)
    .max(11)
    .matches(new RegExp(patterns.phone))
    .required(),
  email: yup.string().email().min(5).max(30).required(),
  password: yup
    .string()
    .min(7)
    .max(20)
    .matches(new RegExp(patterns.password))
    .required(),
  repeatPassword: yup
    .string()
    .oneOf([yup.ref("password")])
    .required(),
  address: yup.object().shape({
    country: yup.string().min(2).max(100).required(),
    state: yup.string().min(0).max(100).default(""),
    city: yup.string().min(2).max(100).required(),
    street: yup.string().min(2).max(100).required(),
    houseNumber: yup.string().min(1).max(10).required(),
    postalCode: yup.string().min(1).max(10).required(),
  }),
  role: yup.object().shape({
    name: yup.string().required(),
  }),
});
