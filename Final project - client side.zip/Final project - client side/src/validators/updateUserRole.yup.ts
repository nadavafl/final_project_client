import * as yup from "yup";
import { IUserInput } from "../types/models";

export const yupUpdateRoleSchema = yup.object<IUserInput>().shape({
  role: yup.object().shape({
    name: yup.string().required(),
  }),
});
