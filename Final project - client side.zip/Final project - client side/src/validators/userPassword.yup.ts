import * as yup from "yup";
import { patterns } from "./regexPatterns";
import { IUserInput } from "../types/models";

export const yupPasswordSchema = yup.object<IUserInput>().shape({
  password: yup
    .string()
    .min(7)
    .max(20)
    .matches(new RegExp(patterns.password))
    .required(),
  repeatPassword: yup
    .string()
    .oneOf([yup.ref("password")])
    .required(),
});
