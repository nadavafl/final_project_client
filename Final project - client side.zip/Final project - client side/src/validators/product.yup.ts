import * as yup from "yup";

export const yupProductSchema = yup.object().shape({
  product_number: yup.string().required(),
  title: yup.string().min(2).max(100).required(),
  description: yup.string().min(2).max(500).required(),
  stock: yup.number(),
  inStock: yup.string().oneOf(["In Stock", "Out of Stock"]).required(),
  price: yup.number().required(),
});
