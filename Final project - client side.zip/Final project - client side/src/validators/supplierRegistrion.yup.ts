import * as yup from "yup";
import { patterns } from "./regexPatterns";
import { IAddress, IOrderDetail, ISupplierInput } from "../types/models";

export const yupSupplierSchema = yup.object<ISupplierInput>().shape({
  businessType: yup
    .object()
    .shape({
      type: yup.array().of(yup.string().required()).required(),
    })
    .required(),
  title: yup.string().min(2).max(150).required(),
  subtitle: yup.string().min(2).max(150).required(),
  description: yup.string().min(2).max(500).required(),
  phone: yup
    .string()
    .min(9)
    .max(11)
    .matches(new RegExp(patterns.phone))
    .required(),
  email: yup.string().email().min(5).max(30).required(),
  web: yup.string().min(0).max(100),
  address: yup.object<IAddress>().shape({
    country: yup.string().min(2).max(100).required(),
    state: yup.string().min(0).max(100).default(""),
    city: yup.string().min(2).max(100).required(),
    street: yup.string().min(2).max(100).required(),
    houseNumber: yup.string().min(1).max(10).required(),
    postalCode: yup.string().min(1).max(10).required(),
  }),
  orderDetail: yup.object<IOrderDetail>().shape({
    minOrder: yup.number().min(1),
    deliveryAreaDays: yup.string().min(2).max(100),
    deliveryCost: yup.number().min(0),
  }),
});
