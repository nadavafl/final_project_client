import * as yup from "yup";
import { patterns } from "./regexPatterns";
import { ILogin } from "../types/models";

export const yupUserLoginSchema = yup.object<ILogin>().shape({
  email: yup.string().email().min(5).max(30).required(),
  password: yup
    .string()
    .min(7)
    .max(20)
    .matches(new RegExp(patterns.password))
    .required(),
});
